# راهنمای ساخت Loop Motion v19.1 — لوگوی اصلی و اصلاح کامپایل

این نسخه بر پایهٔ v19 ساخته شده است. خطای Kotlin مربوط به `singleLine` اصلاح شده و لوگوی اپلیکیشن از فایل اصلی **Golden Crescent Night App Icon.png** برداشته شده است. تصویر دوباره طراحی نشده؛ فقط محدودهٔ آیکون مربعی از تصویر اصلی برش خورده و برای اندازه‌های مختلف اندروید مقیاس‌بندی شده است.

## ساخت در ویندوز

1. ZIP را در یک پوشهٔ جدید استخراج کنید.
2. پوشهٔ `loop-motion-personal` را در Android Studio باز کنید.
3. در Terminal ریشهٔ پروژه اجرا کنید:

```powershell
.\gradlew.bat :uhabits-android:assembleDebug --no-daemon --stacktrace --console=plain
```

APK در این مسیر ساخته می‌شود:

```text
uhabits-android\build\outputs\apk\debug\uhabits-android-debug.apk
```

## اصلاحات

- `singleLine = true` با فراخوانی معتبر `setSingleLine(true)` جایگزین شد.
- فایل اصلی تصویر در `docs/branding/Golden Crescent Night App Icon - Original.png` بدون تغییر نگهداری شده است.
- برش مستقیم تصویر در `docs/branding/Golden Crescent Night App Icon - Cropped.png` قرار دارد.
- آیکون لانچر، foreground آیکون تطبیقی، آیکون وب و تصویر Splash از همان برش تصویر اصلی استفاده می‌کنند.
- نسخه به `2.3.2-personal.18` و `versionCode=20318` ارتقا یافته است.
- شناسهٔ برنامه و دیتابیس تغییر نکرده‌اند؛ مهاجرت دیتابیس جدیدی وجود ندارد.

برای ارتقای نصب قبلی، از امضای Debug قبلی روی همان دستگاه استفاده کنید؛ برنامه را Uninstall یا Clear Data نکنید.

**توجه:** این بسته از نظر سورس و منابع بررسی شده است؛ کامپایل کامل Gradle و اجرای APK باید با دستور بالا روی رایانهٔ شما تأیید شود.
