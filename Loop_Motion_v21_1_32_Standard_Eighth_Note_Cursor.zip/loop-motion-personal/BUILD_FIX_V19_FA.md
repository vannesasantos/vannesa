# راهنمای ساخت Loop Motion v19 — لوگوی ماه و تم رنگی

این نسخه بر پایهٔ سورس v18 ساخته شده و لوگوی اصلی ماه را در آیکون برنامه، آیکون تطبیقی اندروید و صفحهٔ شروع قرار می‌دهد. پالت روشن و تاریک نیز با رنگ‌های سرمه‌ای و طلایی لوگو هماهنگ شده است.

## ساخت در ویندوز

1. ZIP را در یک پوشهٔ جدید استخراج کنید.
2. پوشهٔ `loop-motion-personal` را در Android Studio باز کنید.
3. در Terminal ریشهٔ پروژه اجرا کنید:

```powershell
.\gradlew.bat :uhabits-android:assembleDebug --no-daemon --stacktrace --console=plain
```

APK در این مسیر ساخته می‌شود:

```text
uhabits-android\build\outputs\apk\debug\uhabits-android-debug.apk
```

## نکات ارتقا

- شناسهٔ برنامه ثابت مانده است: `org.isoron.uhabits.personal`.
- نسخه به `2.3.2-personal.17` و `versionCode=20317` ارتقا یافته است.
- این نسخه تغییر دیتابیس یا مهاجرت داده ندارد.
- برای ارتقای نصب قبلی، از امضای Debug قبلی روی همان دستگاه استفاده کنید؛ برنامه را Uninstall یا Clear Data نکنید.
- اگر Android Studio دربارهٔ همگام‌سازی Gradle پرسید، ابتدا Sync Project with Gradle Files را اجرا کنید.

## دارایی‌های برند

- سورس قابل ویرایش لوگو: `docs/branding/Loop_Motion_Moon_Logo_Original.svg`
- پیش‌نمایش لوگو: `docs/branding/Loop_Motion_Moon_Logo_Preview.png`
- جدول رنگ‌ها: `docs/branding/BRAND_PALETTE_FA.md`

ساخت APK در محیط آماده‌سازی این بسته انجام نشده است؛ پس از اجرای دستور بالا نتیجهٔ Gradle باید بررسی شود.
