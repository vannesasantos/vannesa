# Loop Motion v21.1.10 — AAPT String Resource Fix

این نسخه بر پایهٔ v21.1.9 (Polished Motion) ساخته شده است.

## اصلاح
- آپاستروف عبارت صفحهٔ اصلی `Don't you wanna leave this Hell` در منبع Android string به‌درستی escape شد (`Don\'t ...`).
- متن قابل نمایش برای کاربر تغییری نکرده است.
- اصلاحات انیمیشن‌ها و بازخورد لمسی نسخهٔ ۲۱.۱.۹ بدون تغییر حفظ شده‌اند.

## حفظ داده و سازگاری
- هیچ تغییری در دیتابیس یا migration ایجاد نشده است.
- شناسهٔ بسته حفظ شده است.
- `versionName`: `2.3.2-personal.31`
- `versionCode`: `20331`

## وضعیت بررسی
- تمام فایل‌های XML با XML parser بررسی شدند.
- منابع values از نظر apostrophe خام در متن string کنترل شدند.
- ساخت کامل Gradle در این محیط اجرا نشده است؛ تست نهایی AAPT باید با Gradle در محیط Android Studio انجام شود.
