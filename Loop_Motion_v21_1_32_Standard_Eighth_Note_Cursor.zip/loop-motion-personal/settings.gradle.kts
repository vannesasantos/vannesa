pluginManagement {
    repositories {
        // Android Gradle Plugin and AAPT2 are published in Google's Maven repository.
        // Keep the Plugin Portal as a fallback for plugins hosted there.
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}

include(":uhabits-android", ":uhabits-core")
dependencyResolutionManagement {
    @Suppress("UnstableApiUsage")
    repositories {
        google {
            content {
                includeGroupByRegex("com\\.android.*")
                includeGroupByRegex("com\\.google.*")
                includeGroupByRegex("androidx.*")
            }
        }
        mavenCentral()
        // Do not add gradlePluginPortal() here: plugin repositories are configured
        // separately above. Keep only repositories needed for project libraries.
        maven(url = "https://oss.sonatype.org/content/repositories/snapshots/")
        maven(url = "https://jitpack.io")
    }
}

include(":uhabits-android", ":uhabits-core")
