/*
 * Loop Motion's optional ambient rain soundtrack.
 * The audio is bundled with the app and only plays while an app screen is
 * in the foreground. It is controlled by the Rain ambience setting.
 */
package org.isoron.uhabits.activities

import android.app.Activity
import android.app.Application
import android.content.SharedPreferences
import android.media.MediaPlayer
import android.util.Log
import androidx.preference.PreferenceManager
import org.isoron.uhabits.R

class RainAmbienceController(
    private val application: Application
) : Application.ActivityLifecycleCallbacks {

    private val preferences = PreferenceManager.getDefaultSharedPreferences(application)
    private var startedActivityCount = 0
    private var mediaPlayer: MediaPlayer? = null

    private val preferenceListener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        if (key == PREFERENCE_KEY) updatePlayback()
    }

    init {
        preferences.registerOnSharedPreferenceChangeListener(preferenceListener)
    }

    override fun onActivityStarted(activity: Activity) {
        startedActivityCount += 1
        updatePlayback()
    }

    override fun onActivityStopped(activity: Activity) {
        startedActivityCount = (startedActivityCount - 1).coerceAtLeast(0)
        updatePlayback()
    }

    private fun updatePlayback() {
        val shouldPlay = startedActivityCount > 0 &&
            preferences.getBoolean(PREFERENCE_KEY, DEFAULT_ENABLED)
        if (shouldPlay) startPlayback() else stopPlayback()
    }

    private fun startPlayback() {
        if (mediaPlayer != null) return

        val player = try {
            MediaPlayer.create(application, R.raw.rain_ambience)
        } catch (error: RuntimeException) {
            Log.w(TAG, "Unable to prepare rain ambience", error)
            null
        } ?: return

        player.isLooping = true
        player.setVolume(0.22f, 0.22f)
        player.setOnErrorListener { failedPlayer, what, extra ->
            Log.w(TAG, "Rain ambience playback error: $what / $extra")
            if (mediaPlayer === failedPlayer) mediaPlayer = null
            failedPlayer.release()
            true
        }

        mediaPlayer = player
        try {
            player.start()
        } catch (error: RuntimeException) {
            Log.w(TAG, "Unable to start rain ambience", error)
            mediaPlayer = null
            player.release()
        }
    }

    private fun stopPlayback() {
        mediaPlayer?.let { player ->
            mediaPlayer = null
            try {
                player.release()
            } catch (error: RuntimeException) {
                Log.w(TAG, "Unable to release rain ambience", error)
            }
        }
    }

    fun dispose() {
        preferences.unregisterOnSharedPreferenceChangeListener(preferenceListener)
        startedActivityCount = 0
        stopPlayback()
    }

    override fun onActivityCreated(activity: Activity, savedInstanceState: android.os.Bundle?) = Unit
    override fun onActivityResumed(activity: Activity) = Unit
    override fun onActivityPaused(activity: Activity) = Unit
    override fun onActivitySaveInstanceState(activity: Activity, outState: android.os.Bundle) = Unit
    override fun onActivityDestroyed(activity: Activity) = Unit

    companion object {
        const val PREFERENCE_KEY = "pref_rain_ambience"
        const val DEFAULT_ENABLED = true
        private const val TAG = "RainAmbience"
    }
}
