/*
 * Copyright (C) 2016-2026 Loop Motion contributors
 *
 * This file is part of Loop Motion, based on Loop Habit Tracker.
 * It is distributed under the GNU General Public License, version 3 or later.
 */
package org.isoron.uhabits.activities.common.dialogs

import android.app.Dialog
import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.widget.AppCompatButton
import androidx.core.content.ContextCompat
import androidx.fragment.app.DialogFragment
import org.isoron.uhabits.R
import org.isoron.uhabits.utils.MotionFeedback
import org.isoron.uhabits.core.models.PaletteColor
import org.isoron.uhabits.core.ui.callbacks.OnColorPickedCallback
import java.util.Locale
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin

/** Full-spectrum HSV color picker with persistent favorite colors. */
class ColorPickerDialog : DialogFragment() {
    private var callback: OnColorPickedCallback? = null
    private var currentColor: Int = Color.RED
    private lateinit var wheel: ColorWheelView
    private lateinit var preview: View
    private lateinit var hexInput: EditText
    private lateinit var favoritesRow: LinearLayout
    private lateinit var brightness: SeekBar
    private var syncingControls = false

    fun setListener(callback: OnColorPickedCallback) {
        this.callback = callback
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        currentColor = savedInstanceState?.getInt(STATE_COLOR)
            ?: arguments?.getInt(ARG_INITIAL_COLOR, Color.RED)
            ?: Color.RED
    }

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        val context = requireContext()
        val content = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(context, 20), dp(context, 8), dp(context, 20), dp(context, 8))
        }

        preview = View(context).apply {
            background = roundedColorDrawable(currentColor, dp(context, 12).toFloat())
            contentDescription = context.getString(R.string.color_picker_preview)
        }
        content.addView(preview, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, dp(context, 42)
        ).apply { bottomMargin = dp(context, 12) })

        wheel = ColorWheelView(context, currentColor).apply {
            contentDescription = context.getString(R.string.color_picker_wheel_description)
            onColorChanged = { color -> setCurrentColor(color, updateWheel = false) }
        }
        content.addView(wheel, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, dp(context, 260)
        ).apply { bottomMargin = dp(context, 8) })

        val brightnessLabel = TextView(context).apply {
            text = context.getString(R.string.color_picker_brightness)
            textSize = 13f
        }
        content.addView(brightnessLabel)

        brightness = SeekBar(context).apply {
            max = 100
            progress = 100
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    if (fromUser && !syncingControls) {
                        wheel.setBrightness((progress.coerceIn(2, 100)) / 100f)
                    }
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) = Unit
                override fun onStopTrackingTouch(seekBar: SeekBar?) = Unit
            })
        }
        val hsv = FloatArray(3)
        Color.colorToHSV(currentColor, hsv)
        brightness.progress = (hsv[2] * 100).roundToInt()
        content.addView(brightness, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { bottomMargin = dp(context, 10) })

        val hexLabel = TextView(context).apply {
            text = context.getString(R.string.color_picker_hex_label)
            textSize = 13f
        }
        content.addView(hexLabel)
        hexInput = EditText(context).apply {
            setSingleLine(true)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS
            hint = "#RRGGBB"
            setText(formatHex(currentColor))
            selectAll()
        }
        content.addView(hexInput, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { bottomMargin = dp(context, 12) })

        val favoritesHeader = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val favoritesTitle = TextView(context).apply {
            text = context.getString(R.string.color_picker_favorites)
            textSize = 14f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        }
        favoritesHeader.addView(favoritesTitle, LinearLayout.LayoutParams(0, dp(context, 42), 1f))
        val saveBackground = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dp(context, 12).toFloat()
            setColor(ContextCompat.getColor(context, R.color.motion_brand_gold))
        }
        val saveMask = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dp(context, 12).toFloat()
            setColor(Color.WHITE)
        }
        val saveFavoriteButton = AppCompatButton(context).apply {
            text = context.getString(R.string.color_picker_save_favorite)
            isAllCaps = false
            setTextColor(ContextCompat.getColor(context, R.color.motion_brand_night))
            background = RippleDrawable(
                ColorStateList.valueOf(ContextCompat.getColor(context, R.color.motion_gold_ripple_strong)),
                saveBackground,
                saveMask
            )
            minHeight = dp(context, 36)
            minimumHeight = dp(context, 36)
            setPadding(dp(context, 14), 0, dp(context, 14), 0)
            textSize = 12f
            setOnClickListener { saveFavorite() }
            MotionFeedback.bindPress(this, pressedScale = 0.96f)
        }
        favoritesHeader.addView(
            saveFavoriteButton,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(context, 36))
        )
        content.addView(favoritesHeader)

        val favoritesScroll = HorizontalScrollView(context).apply {
            isHorizontalScrollBarEnabled = false
        }
        favoritesRow = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        favoritesScroll.addView(favoritesRow)
        content.addView(favoritesScroll, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, dp(context, 52)
        ))
        refreshFavorites()

        val help = TextView(context).apply {
            text = context.getString(R.string.color_picker_favorites_help)
            textSize = 11f
            alpha = 0.72f
        }
        content.addView(help)

        val scroll = android.widget.ScrollView(context).apply {
            isFillViewport = true
            addView(content)
        }
        val dialog = AlertDialog.Builder(context)
            .setTitle(R.string.color_picker_default_title)
            .setView(scroll)
            .setNegativeButton(android.R.string.cancel, null)
            .setPositiveButton(R.string.color_picker_select, null)
            .create()

        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val parsed = parseHex(hexInput.text?.toString().orEmpty())
                if (parsed == null) {
                    hexInput.error = getString(R.string.color_picker_invalid_hex)
                    return@setOnClickListener
                }
                currentColor = parsed
                callback?.onColorPicked(PaletteColor.fromArgb(parsed))
                dismiss()
            }
            dialog.getButton(AlertDialog.BUTTON_POSITIVE)?.let { MotionFeedback.bindPress(it) }
        }
        syncControls(currentColor)
        return dialog
    }

    override fun onStart() {
        super.onStart()
        dialog?.window?.setLayout(
            (resources.displayMetrics.widthPixels * 0.94f).roundToInt(),
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
        MotionFeedback.dialogContent(dialog)
    }

    override fun onSaveInstanceState(outState: Bundle) {
        outState.putInt(STATE_COLOR, currentColor)
        super.onSaveInstanceState(outState)
    }

    private fun setCurrentColor(color: Int, updateWheel: Boolean = true) {
        currentColor = color
        if (updateWheel && ::wheel.isInitialized) wheel.setColor(color)
        syncControls(color)
    }

    private fun syncControls(color: Int) {
        if (!::preview.isInitialized || !::hexInput.isInitialized || !::brightness.isInitialized) return
        syncingControls = true
        preview.background = roundedColorDrawable(color, dp(requireContext(), 12).toFloat())
        val formatted = formatHex(color)
        if (hexInput.text.toString() != formatted) {
            hexInput.setText(formatted)
            hexInput.setSelection(formatted.length)
        }
        val hsv = FloatArray(3)
        Color.colorToHSV(color, hsv)
        brightness.progress = (hsv[2] * 100).roundToInt()
        syncingControls = false
    }

    private fun saveFavorite() {
        val typedColor = parseHex(hexInput.text?.toString().orEmpty())
        if (typedColor == null) {
            hexInput.error = getString(R.string.color_picker_invalid_hex)
            return
        }
        setCurrentColor(typedColor)
        val favorites = readFavorites(requireContext())
        if (favorites.contains(currentColor)) {
            Toast.makeText(requireContext(), R.string.color_picker_already_saved, Toast.LENGTH_SHORT).show()
            return
        }
        if (favorites.size >= MAX_FAVORITES) {
            Toast.makeText(requireContext(), R.string.color_picker_favorites_full, Toast.LENGTH_SHORT).show()
            return
        }
        favorites.add(currentColor)
        writeFavorites(requireContext(), favorites)
        refreshFavorites()
        Toast.makeText(requireContext(), R.string.color_picker_favorite_saved, Toast.LENGTH_SHORT).show()
    }

    private fun refreshFavorites() {
        if (!::favoritesRow.isInitialized) return
        favoritesRow.removeAllViews()
        val context = requireContext()
        val favorites = readFavorites(context)
        if (favorites.isEmpty()) {
            favoritesRow.addView(TextView(context).apply {
                text = context.getString(R.string.color_picker_no_favorites)
                textSize = 12f
                alpha = 0.7f
            })
            return
        }
        favorites.forEachIndexed { index, color ->
            val swatch = TextView(context).apply {
                text = "●"
                textSize = 23f
                gravity = Gravity.CENTER
                setTextColor(contrastingText(color))
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(color)
                    setStroke(1, ContextCompat.getColor(context, R.color.motion_gold_border))
                }
                contentDescription = formatHex(color)
                setOnClickListener {
                    MotionFeedback.selection(this)
                    setCurrentColor(color)
                }
                MotionFeedback.bindPress(this, pressedScale = 0.9f)
                setOnLongClickListener {
                    AlertDialog.Builder(context)
                        .setMessage(context.getString(R.string.color_picker_remove_favorite, formatHex(color)))
                        .setNegativeButton(android.R.string.cancel, null)
                        .setPositiveButton(R.string.color_picker_remove) { _, _ ->
                            val updated = readFavorites(context).filterNot { it == color }
                            writeFavorites(context, updated)
                            refreshFavorites()
                        }
                        .show()
                    true
                }
            }
            favoritesRow.addView(swatch, LinearLayout.LayoutParams(dp(context, 38), dp(context, 38)).apply {
                marginEnd = dp(context, 8)
            })
            MotionFeedback.entrance(swatch, delayMillis = (index * 12L).coerceAtMost(150L), distanceDp = 4f)
        }
    }

    private fun roundedColorDrawable(color: Int, radius: Float) = GradientDrawable().apply {
        cornerRadius = radius
        setColor(color)
        setStroke(1, ContextCompat.getColor(requireContext(), R.color.motion_gold_border))
    }

    private fun contrastingText(color: Int): Int {
        val hsv = FloatArray(3)
        Color.colorToHSV(color, hsv)
        return if (hsv[2] < 0.58f) Color.WHITE else Color.BLACK
    }

    private fun parseHex(value: String): Int? {
        val normalized = value.trim().let { if (it.startsWith("#")) it else "#$it" }
        return try {
            Color.parseColor(normalized)
        } catch (_: IllegalArgumentException) {
            null
        }
    }

    private fun formatHex(color: Int): String = String.format(Locale.US, "#%06X", color and 0xFFFFFF)

    private fun readFavorites(context: Context): MutableList<Int> {
        val stored = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getString(KEY_FAVORITES, "") ?: ""
        return stored.split(',').mapNotNull { parseHex(it) }.distinct().take(MAX_FAVORITES).toMutableList()
    }

    private fun writeFavorites(context: Context, colors: List<Int>) {
        val encoded = colors.take(MAX_FAVORITES).joinToString(",") { formatHex(it) }
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit().putString(KEY_FAVORITES, encoded).apply()
    }

    private fun dp(context: Context, value: Int): Int =
        (value * context.resources.displayMetrics.density).roundToInt()

    /** Hue is selected by angle and saturation by distance from the center. */
    private class ColorWheelView(context: Context, initialColor: Int) : View(context) {
        var onColorChanged: ((Int) -> Unit)? = null
        private val bitmapPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
        private val markerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = dp(context, 3).toFloat()
            color = Color.WHITE
        }
        private val markerShadowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = dp(context, 1).toFloat()
            color = Color.BLACK
        }
        private var wheelBitmap: Bitmap? = null
        private var hue = 0f
        private var saturation = 1f
        private var value = 1f

        init {
            setColor(initialColor)
        }

        fun setColor(color: Int) {
            val hsv = FloatArray(3)
            Color.colorToHSV(color, hsv)
            hue = hsv[0]
            saturation = hsv[1]
            value = hsv[2]
            wheelBitmap = null
            invalidate()
        }

        fun setBrightness(value: Float) {
            this.value = value.coerceIn(0.02f, 1f)
            // Keep the hue/saturation wheel visually constant. Brightness is
            // reflected by the selected color preview and HEX value only.
            notifyColorChanged()
            invalidate()
        }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val side = min(width, height).toFloat()
            val left = (width - side) / 2f
            val top = (height - side) / 2f
            val bitmap = wheelBitmap ?: createWheelBitmap().also { wheelBitmap = it }
            val wheelRect = RectF(left, top, left + side, top + side)
            canvas.drawBitmap(bitmap, null, wheelRect, bitmapPaint)

            val radius = side / 2f - dp(context, 3)
            val markerRadius = saturation * radius
            val markerX = left + side / 2f + cos(Math.toRadians(hue.toDouble())).toFloat() * markerRadius
            val markerY = top + side / 2f + sin(Math.toRadians(hue.toDouble())).toFloat() * markerRadius
            canvas.drawCircle(markerX, markerY, dp(context, 10).toFloat(), markerShadowPaint)
            canvas.drawCircle(markerX, markerY, dp(context, 10).toFloat(), markerPaint)
        }

        override fun onTouchEvent(event: MotionEvent): Boolean {
            if (event.action != MotionEvent.ACTION_DOWN && event.action != MotionEvent.ACTION_MOVE &&
                event.action != MotionEvent.ACTION_UP
            ) return false
            val side = min(width, height).toFloat()
            val left = (width - side) / 2f
            val top = (height - side) / 2f
            val cx = left + side / 2f
            val cy = top + side / 2f
            val dx = event.x - cx
            val dy = event.y - cy
            val radius = (side / 2f - dp(context, 3)).coerceAtLeast(1f)
            val distance = kotlin.math.sqrt(dx * dx + dy * dy).coerceAtMost(radius)
            hue = ((Math.toDegrees(atan2(dy.toDouble(), dx.toDouble())) + 360.0) % 360.0).toFloat()
            saturation = (distance / radius).coerceIn(0f, 1f)
            notifyColorChanged()
            invalidate()
            return true
        }

        private fun notifyColorChanged() {
            onColorChanged?.invoke(Color.HSVToColor(floatArrayOf(hue, saturation, value)))
        }

        private fun createWheelBitmap(): Bitmap {
            val size = 300
            val pixels = IntArray(size * size)
            val center = (size - 1) / 2f
            val radius = center
            val hsv = FloatArray(3)
            for (y in 0 until size) {
                for (x in 0 until size) {
                    val dx = x - center
                    val dy = y - center
                    val distance = kotlin.math.sqrt(dx * dx + dy * dy)
                    if (distance > radius) {
                        pixels[y * size + x] = Color.TRANSPARENT
                    } else {
                        hsv[0] = ((Math.toDegrees(atan2(dy.toDouble(), dx.toDouble())) + 360.0) % 360.0).toFloat()
                        hsv[1] = (distance / radius).coerceIn(0f, 1f)
                        hsv[2] = 1f
                        pixels[y * size + x] = Color.HSVToColor(hsv)
                    }
                }
            }
            return Bitmap.createBitmap(pixels, size, size, Bitmap.Config.ARGB_8888)
        }

        override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
            super.onSizeChanged(w, h, oldw, oldh)
            wheelBitmap = null
        }

        companion object {
            private fun dp(context: Context, value: Int): Int =
                (value * context.resources.displayMetrics.density).roundToInt()
        }
    }

    companion object {
        private const val ARG_INITIAL_COLOR = "initial_color"
        private const val STATE_COLOR = "current_color"
        private const val PREFS_NAME = "loop_motion_color_picker"
        private const val KEY_FAVORITES = "favorite_colors"
        private const val MAX_FAVORITES = 16

        fun newInstance(initialColor: Int): ColorPickerDialog = ColorPickerDialog().apply {
            arguments = Bundle().apply { putInt(ARG_INITIAL_COLOR, initialColor) }
        }
    }
}
