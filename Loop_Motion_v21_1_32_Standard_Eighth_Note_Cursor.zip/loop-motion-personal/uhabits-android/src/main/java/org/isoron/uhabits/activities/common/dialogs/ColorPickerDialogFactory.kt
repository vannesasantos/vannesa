/*
 * Copyright (C) 2016-2021 Álinson Santos Xavier <git@axavier.org>
 *
 * This file is part of Loop Habit Tracker.
 * It is distributed under the GNU General Public License, version 3 or later.
 */
package org.isoron.uhabits.activities.common.dialogs

import android.content.Context
import org.isoron.platform.gui.toInt
import org.isoron.uhabits.core.models.PaletteColor
import org.isoron.uhabits.core.ui.views.Theme
import org.isoron.uhabits.inject.ActivityContext
import org.isoron.uhabits.inject.ActivityScope
import javax.inject.Inject

@ActivityScope
class ColorPickerDialogFactory @Inject constructor(@param:ActivityContext private val context: Context) {
    fun create(color: PaletteColor, theme: Theme): ColorPickerDialog {
        return ColorPickerDialog.newInstance(theme.color(color).toInt())
    }
}
