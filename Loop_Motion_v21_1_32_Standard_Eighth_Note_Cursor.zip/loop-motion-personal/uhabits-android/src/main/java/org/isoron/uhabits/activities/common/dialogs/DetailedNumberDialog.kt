/*
 * Copyright (C) 2016-2021 Álinson Santos Xavier
 * This file is part of Loop Habit Tracker and is distributed under GPL-3.0-or-later.
 */
package org.isoron.uhabits.activities.common.dialogs

import android.app.Dialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatDialogFragment
import org.isoron.uhabits.R
import org.isoron.uhabits.core.models.NumericalEntryLog
import org.isoron.uhabits.core.models.Entry
import org.isoron.uhabits.core.models.TimeUnitUtils
import org.isoron.uhabits.databinding.DetailedNumberPopupBinding
import org.isoron.uhabits.utils.sres
import org.isoron.uhabits.utils.MotionFeedback
import java.text.DecimalFormat
import java.text.NumberFormat
import java.text.ParseException
import kotlin.math.roundToInt
import kotlin.math.roundToLong

class DetailedNumberDialog : AppCompatDialogFragment() {

    var onSaved: (List<NumericalEntryLog>, Boolean) -> Unit = { _, _ -> }
    var onSetStatus: (Int) -> Unit = {}

    private lateinit var binding: DetailedNumberPopupBinding
    private val entries = mutableListOf<NumericalEntryLog>()
    private var unit: String = ""
    private var timeMinutesPerUnit: Double? = null
    private var useClockInput = false
    private var editingIndex: Int? = null
    private var currentDayValue: Int = 0
    private var entriesEdited = false
    private var entryAnimationIndex: Int? = null

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        binding = DetailedNumberPopupBinding.inflate(LayoutInflater.from(context))
        unit = requireArguments().getString("unit", "")
        currentDayValue = requireArguments().getInt("currentValue", 0)
        timeMinutesPerUnit = TimeUnitUtils.minutesPerUnit(unit)
        val values = requireArguments().getIntArray("logValues") ?: intArrayOf()
        val notes = requireArguments().getStringArray("logNotes") ?: emptyArray()
        val kinds = requireArguments().getIntArray("logKinds") ?: intArrayOf()
        val timeMinutes = requireArguments().getLongArray("logTimeMinutesMilli") ?: longArrayOf()
        val timestamp = requireArguments().getLong("timestamp")
        values.forEachIndexed { index, value ->
            entries.add(
                NumericalEntryLog(
                    timestamp = org.isoron.uhabits.core.models.Timestamp(timestamp),
                    value = value,
                    notes = notes.getOrElse(index) { "" },
                    kind = NumericalEntryLog.Kind.fromInt(kinds.getOrElse(index) { 0 }),
                    timeMinutesMilli = timeMinutes.getOrNull(index)?.takeIf { it != Long.MIN_VALUE }
                )
            )
        }

        // A legacy Simple-mode day may have a daily value but no detailed rows.
        // Represent that value as a baseline so switching to Detailed cannot
        // silently replace the old total with only the next newly added session.
        if (entries.isEmpty() && currentDayValue != 0 &&
            currentDayValue != Entry.SKIP && currentDayValue != Entry.UNKNOWN
        ) {
            val exactMinutesMilli = timeMinutesPerUnit?.let { factor ->
                ((currentDayValue / 1000.0) * factor).roundToLong() * 1000L
            }
            entries.add(
                NumericalEntryLog(
                    timestamp = org.isoron.uhabits.core.models.Timestamp(timestamp),
                    value = currentDayValue,
                    notes = requireArguments().getString("currentNotes") ?: "",
                    kind = NumericalEntryLog.Kind.PREVIOUS_TOTAL,
                    timeMinutesMilli = exactMinutesMilli
                )
            )
        }

        setupTimeInput()
        binding.addEntryButton.setOnClickListener { addOrUpdateEntry() }
        binding.skipDayButton.visibility = if (requireArguments().getBoolean("skipEnabled")) View.VISIBLE else View.GONE
        binding.unknownDayButton.visibility = if (requireArguments().getBoolean("unknownEnabled")) View.VISIBLE else View.GONE
        binding.skipDayButton.setOnClickListener {
            onSetStatus(Entry.SKIP)
            requireDialog().dismiss()
        }
        binding.unknownDayButton.setOnClickListener {
            onSetStatus(Entry.UNKNOWN)
            requireDialog().dismiss()
        }
        binding.saveButton.setOnClickListener {
            onSaved(entries.toList(), entriesEdited)
            requireDialog().dismiss()
        }
        listOf(binding.addEntryButton, binding.skipDayButton, binding.unknownDayButton, binding.saveButton)
            .filter { it.visibility == View.VISIBLE }
            .forEach { MotionFeedback.bindPress(it) }
        binding.valueInput.requestFocus()
        renderEntries()

        val dialog = Dialog(requireContext())
        dialog.setContentView(binding.root)
        dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)
        return dialog
    }

    private fun setupTimeInput() {
        if (timeMinutesPerUnit == null) return
        binding.timeFormatPicker.visibility = View.VISIBLE
        MotionFeedback.bindPress(binding.timeMinutesMode, pressedScale = 0.97f)
        MotionFeedback.bindPress(binding.timeClockMode, pressedScale = 0.97f)
        binding.timeMinutesMode.setOnClickListener {
            if (useClockInput) {
                val total = readClockMinutes()
                binding.valueInput.setText(DecimalFormat("#.###").format(total))
                useClockInput = false
                updateInputMode()
            }
        }
        binding.timeClockMode.setOnClickListener {
            if (!useClockInput) {
                val total = parseNumber(binding.valueInput.text.toString()).coerceAtLeast(0.0)
                val hours = (total / 60.0).toInt()
                val minutes = total - hours * 60.0
                binding.timeHoursInput.setText(hours.toString())
                binding.timeMinutesInput.setText(DecimalFormat("#.###").format(minutes))
                useClockInput = true
                updateInputMode()
            }
        }
        updateInputMode()
    }

    private fun updateInputMode() {
        binding.valueInput.visibility = if (useClockInput) View.GONE else View.VISIBLE
        binding.timeClockFields.visibility = if (useClockInput) View.VISIBLE else View.GONE
        binding.timeMinutesMode.setTextColor(
            binding.root.sres.getColor(if (useClockInput) R.attr.contrast60 else R.attr.contrast100)
        )
        binding.timeClockMode.setTextColor(
            binding.root.sres.getColor(if (useClockInput) R.attr.contrast100 else R.attr.contrast60)
        )
    }

    private fun readClockMinutes(): Double {
        val hours = parseNumber(binding.timeHoursInput.text.toString()).coerceAtLeast(0.0)
        val minutes = parseNumber(binding.timeMinutesInput.text.toString()).coerceAtLeast(0.0)
        return hours * 60.0 + minutes
    }

    private fun readTimeMinutes(): Double? {
        if (timeMinutesPerUnit == null) return null
        return (if (useClockInput) readClockMinutes() else parseNumber(binding.valueInput.text.toString()))
            .coerceAtLeast(0.0)
    }

    private fun readValueInHabitUnits(): Double {
        val factor = timeMinutesPerUnit
        if (factor != null) return (readTimeMinutes() ?: 0.0) / factor
        return parseNumber(binding.valueInput.text.toString())
    }

    private fun addOrUpdateEntry() {
        val value = readValueInHabitUnits()
        if (value <= 0.0) {
            binding.valueInput.error = getString(R.string.validation_cannot_be_blank)
            return
        }
        val timestamp = org.isoron.uhabits.core.models.Timestamp(requireArguments().getLong("timestamp"))
        val item = NumericalEntryLog(
            timestamp = timestamp,
            value = (value * 1000.0).roundToInt(),
            notes = binding.notesInput.text.toString().trim(),
            kind = editingIndex?.let { entries.getOrNull(it)?.kind } ?: NumericalEntryLog.Kind.ACTIVITY,
            timeMinutesMilli = readTimeMinutes()?.let { (it * 1000.0).roundToLong() }
        )
        val index = editingIndex
        if (index != null && index in entries.indices) {
            entries[index] = item
        } else {
            entries.add(item)
        }
        entriesEdited = true
        entryAnimationIndex = if (index == null) entries.lastIndex else index
        editingIndex = null
        binding.editorTitle.setText(R.string.detailed_add_entry)
        binding.addEntryButton.setText(R.string.detailed_add_entry)
        clearEditor()
        renderEntries()
    }

    private fun clearEditor() {
        binding.valueInput.setText("")
        binding.timeHoursInput.setText("")
        binding.timeMinutesInput.setText("")
        binding.notesInput.setText("")
    }

    private fun editEntry(index: Int) {
        val item = entries.getOrNull(index) ?: return
        if (item.kind == NumericalEntryLog.Kind.SIMPLE_MODE_ADJUSTMENT) return
        editingIndex = index
        binding.editorTitle.setText(R.string.detailed_update_entry)
        binding.addEntryButton.setText(R.string.detailed_update_entry)
        binding.notesInput.setText(item.notes)
        val factor = timeMinutesPerUnit
        if (factor != null) {
            val minutes = (item.timeMinutesMilli?.div(1000.0)
                ?: (item.value / 1000.0 * factor).let { kotlin.math.round(it) })
            if (useClockInput) {
                binding.timeHoursInput.setText((minutes.toInt() / 60).toString())
                binding.timeMinutesInput.setText(DecimalFormat("#.###").format(minutes % 60.0))
            } else {
                binding.valueInput.setText(DecimalFormat("#.###").format(minutes))
            }
        } else {
            binding.valueInput.setText(DecimalFormat("#.##").format(item.value / 1000.0))
        }
    }

    private fun renderEntries() {
        binding.entriesContainer.removeAllViews()
        val total = entries.sumOf { it.value.toLong() } / 1000.0
        val exactMinutesMilli = TimeUnitUtils.totalMinutesMilli(entries, unit)
        binding.dailyTotal.text = when {
            !entriesEdited && currentDayValue == org.isoron.uhabits.core.models.Entry.SKIP ->
                getString(R.string.detailed_day_skipped)
            !entriesEdited && currentDayValue == org.isoron.uhabits.core.models.Entry.UNKNOWN ->
                getString(R.string.detailed_day_unrecorded)
            else -> if (timeMinutesPerUnit != null && exactMinutesMilli != null) {
                formatTimeMinutes(exactMinutesMilli / 1000.0)
            } else {
                formatAmount(total)
            }
        }
        if (entries.isEmpty()) {
            val empty = TextView(requireContext()).apply {
                text = getString(R.string.detailed_no_entries)
                setTextColor(binding.root.sres.getColor(R.attr.contrast60))
                textSize = 13f
                setPadding(8, 12, 8, 12)
            }
            binding.entriesContainer.addView(empty)
            return
        }

        entries.forEachIndexed { index, entry ->
            val row = LinearLayout(requireContext()).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = android.view.Gravity.CENTER_VERTICAL
                setPadding(6, 5, 6, 5)
            }
            val amountAndNote = LinearLayout(requireContext()).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                setPadding(4, 2, 4, 2)
            }
            val amount = TextView(requireContext()).apply {
                val entryAmount = if (timeMinutesPerUnit != null) {
                    val minutes = entry.timeMinutesMilli?.div(1000.0)
                        ?: kotlin.math.round((entry.value / 1000.0) * (timeMinutesPerUnit ?: 1.0))
                    formatTimeMinutes(minutes)
                } else {
                    formatAmount(entry.value / 1000.0)
                }
                text = when (entry.kind) {
                    NumericalEntryLog.Kind.PREVIOUS_TOTAL -> getString(R.string.detailed_previous_total) + " · " + entryAmount
                    NumericalEntryLog.Kind.SIMPLE_MODE_ADJUSTMENT -> getString(R.string.detailed_simple_adjustment) + " · " + entryAmount
                    else -> entryAmount
                }
                setTextColor(binding.root.sres.getColor(R.attr.contrast100))
                textSize = 14f
            }
            amountAndNote.addView(amount)
            if (entry.notes.isNotBlank()) {
                amountAndNote.addView(TextView(requireContext()).apply {
                    text = entry.notes
                    setTextColor(binding.root.sres.getColor(R.attr.contrast60))
                    textSize = 12f
                    maxLines = 2
                })
            }
            row.addView(amountAndNote)
            if (entry.kind != NumericalEntryLog.Kind.SIMPLE_MODE_ADJUSTMENT) {
                row.addView(TextView(requireContext()).apply {
                    text = "✎"
                    textSize = 18f
                    setPadding(10, 6, 10, 6)
                    setTextColor(binding.root.sres.getColor(R.attr.contrast60))
                    setOnClickListener { MotionFeedback.selection(this); editEntry(index) }
                    MotionFeedback.bindPress(this, pressedScale = 0.9f)
                })
                row.addView(TextView(requireContext()).apply {
                    text = "×"
                    textSize = 20f
                    setPadding(10, 6, 8, 6)
                    setTextColor(binding.root.sres.getColor(R.attr.contrast60))
                    setOnClickListener {
                        entries.removeAt(index)
                        entriesEdited = true
                        when {
                            editingIndex == index -> {
                                editingIndex = null
                                clearEditor()
                            }
                            editingIndex != null && editingIndex!! > index -> editingIndex = editingIndex!! - 1
                        }
                        renderEntries()
                    }
                    MotionFeedback.bindPress(this, pressedScale = 0.9f)
                })
            }
            binding.entriesContainer.addView(row)
            if (entryAnimationIndex == index) MotionFeedback.entrance(row, distanceDp = 5f)
            val divider = View(requireContext()).apply {
                setBackgroundColor(binding.root.sres.getColor(R.attr.contrast20))
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    1
                )
            }
            binding.entriesContainer.addView(divider)
        }
        entryAnimationIndex = null
    }

    override fun onStart() {
        super.onStart()
        MotionFeedback.dialogContent(dialog)
    }

    private fun formatAmount(value: Double): String {
        val factor = timeMinutesPerUnit
        if (factor != null) return formatTimeMinutes(value * factor)
        val formatted = DecimalFormat("#.##").format(value)
        return if (unit.isBlank()) formatted else "$formatted $unit"
    }

    private fun formatTimeMinutes(minutes: Double): String {
        val sign = if (minutes < 0) "−" else ""
        return sign + TimeUnitUtils.formatDuration(kotlin.math.abs(minutes))
    }

    private fun parseNumber(value: String): Double {
        return try {
            NumberFormat.getInstance().parse(value)?.toDouble() ?: 0.0
        } catch (_: ParseException) {
            value.replace(',', '.').toDoubleOrNull() ?: 0.0
        }
    }
}
