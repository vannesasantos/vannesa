package org.isoron.uhabits.activities.common.dialogs

import android.app.Dialog
import android.os.Bundle
import android.provider.Settings
import android.text.method.DigitsKeyListener
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.view.inputmethod.EditorInfo
import androidx.appcompat.app.AppCompatDialogFragment
import org.isoron.uhabits.HabitsApplication
import org.isoron.uhabits.R
import org.isoron.uhabits.core.models.Entry
import org.isoron.uhabits.core.models.TimeUnitUtils
import org.isoron.uhabits.databinding.CheckmarkPopupBinding
import org.isoron.uhabits.utils.InterfaceUtils
import org.isoron.uhabits.utils.MotionFeedback
import org.isoron.uhabits.utils.getCenter
import org.isoron.uhabits.utils.requestFocusWithKeyboard
import org.isoron.uhabits.utils.sres
import java.text.DecimalFormat
import java.text.DecimalFormatSymbols
import java.text.NumberFormat
import java.text.ParseException
import kotlin.math.roundToLong
import kotlin.math.roundToInt

class NumberDialog : AppCompatDialogFragment() {

    var onToggle: (Double, String, Long?) -> Unit = { _, _, _ -> }
    var onDismiss: () -> Unit = {}

    private var originalNotes: String = ""
    private var originalValue: Double = 0.0
    private var timeMinutesPerUnit: Double? = null
    private var useClockInput = false
    private var forcedValue: Double? = null
    private var exactCurrentTimeMinutesMilli: Long? = null
    private lateinit var view: CheckmarkPopupBinding

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        val appComponent = (requireActivity().application as HabitsApplication).component
        val prefs = appComponent.preferences
        view = CheckmarkPopupBinding.inflate(LayoutInflater.from(context))
        arrayOf(view.yesBtn).forEach {
            it.setTextColor(requireArguments().getInt("color"))
        }
        arrayOf(view.noBtn, view.unknownBtnNumber).forEach {
            it.setTextColor(view.root.sres.getColor(R.attr.contrast60))
        }
        arrayOf(view.yesBtn, view.noBtn, view.unknownBtnNumber).forEach {
            it.typeface = InterfaceUtils.getFontAwesome(requireContext())
        }
        if (!prefs.isSkipEnabled) view.skipBtnNumber.visibility = View.GONE
        if (!prefs.areQuestionMarksEnabled) view.unknownBtnNumber.visibility = View.GONE
        view.numberButtons.visibility = View.VISIBLE
        fixDecimalSeparator(view)
        originalNotes = requireArguments().getString("notes") ?: ""
        originalValue = requireArguments().getDouble("value")
        timeMinutesPerUnit = TimeUnitUtils.minutesPerUnit(requireArguments().getString("unit", ""))
        exactCurrentTimeMinutesMilli = requireArguments().getLong("timeMinutesMilli", Long.MIN_VALUE)
            .takeIf { it != Long.MIN_VALUE }
        view.notes.setText(originalNotes)
        val isSpecialEntry =
            originalValue == Entry.SKIP.toDouble() / 1000.0 ||
                originalValue == Entry.UNKNOWN.toDouble() / 1000.0
        val initialInputValue = if (isSpecialEntry) 0.0
            else if (timeMinutesPerUnit != null) {
                exactCurrentTimeMinutesMilli?.div(1000.0)
                    ?: kotlin.math.round(originalValue * (timeMinutesPerUnit ?: 1.0))
            } else originalValue
        view.value.setText(
            when {
                initialInputValue < 0.01 -> "0"
                else -> DecimalFormat(if (timeMinutesPerUnit != null) "#.###" else "#.##").format(initialInputValue)
            }
        )
        setupTimeInput()
        view.value.setOnKeyListener { _, keyCode, event ->
            if (event.action == MotionEvent.ACTION_DOWN && keyCode == KeyEvent.KEYCODE_ENTER) {
                save()
                return@setOnKeyListener true
            }
            return@setOnKeyListener false
        }
        view.saveBtn.setOnClickListener {
            save()
        }
        view.skipBtnNumber.setOnClickListener {
            forcedValue = Entry.SKIP.toDouble() / 1000
            save()
        }

        view.unknownBtnNumber.setOnClickListener {
            forcedValue = Entry.UNKNOWN.toDouble() / 1000
            save()
        }
        listOf(view.saveBtn, view.skipBtnNumber, view.unknownBtnNumber)
            .filter { it.visibility == View.VISIBLE }
            .forEach { MotionFeedback.bindPress(it, pressedScale = 0.95f) }

        view.notes.setOnEditorActionListener { v, actionId, event ->
            save()
            true
        }
        view.value.requestFocusWithKeyboard()
        val dialog = Dialog(requireContext())
        dialog.setContentView(view.root)
        dialog.window?.apply {
            setBackgroundDrawableResource(android.R.color.transparent)
        }
        dialog.setOnDismissListener { onDismiss() }
        return dialog
    }

    override fun onStart() {
        super.onStart()
        MotionFeedback.dialogContent(dialog)
    }

    private fun setupTimeInput() {
        if (timeMinutesPerUnit == null) return
        val picker = view.root.findViewById<LinearLayout>(R.id.timeFormatPicker)
        val clockFields = view.root.findViewById<LinearLayout>(R.id.timeClockFields)
        val minutesMode = view.root.findViewById<TextView>(R.id.timeMinutesMode)
        val clockMode = view.root.findViewById<TextView>(R.id.timeClockMode)
        val hoursInput = view.root.findViewById<EditText>(R.id.timeHoursInput)
        val minutesInput = view.root.findViewById<EditText>(R.id.timeMinutesInput)
        picker.visibility = View.VISIBLE

        fun currentTotalMinutes(): Double {
            if (useClockInput) {
                val hours = parseNumber(hoursInput.text.toString()).coerceAtLeast(0.0)
                val minutes = parseNumber(minutesInput.text.toString()).coerceAtLeast(0.0)
                return hours * 60.0 + minutes
            }
            return parseNumber(view.value.text.toString()).coerceAtLeast(0.0)
        }

        fun updateMode() {
            minutesMode.setTextColor(view.root.sres.getColor(
                if (useClockInput) R.attr.contrast60 else R.attr.contrast100
            ))
            clockMode.setTextColor(view.root.sres.getColor(
                if (useClockInput) R.attr.contrast100 else R.attr.contrast60
            ))
            view.value.visibility = if (useClockInput) View.GONE else View.VISIBLE
            clockFields.visibility = if (useClockInput) View.VISIBLE else View.GONE
        }

        MotionFeedback.bindPress(minutesMode, pressedScale = 0.97f)
        MotionFeedback.bindPress(clockMode, pressedScale = 0.97f)
        minutesMode.setOnClickListener {
            if (useClockInput) {
                val total = currentTotalMinutes()
                view.value.setText(DecimalFormat("#.###").format(total))
                useClockInput = false
                updateMode()
            }
        }
        clockMode.setOnClickListener {
            if (!useClockInput) {
                val total = currentTotalMinutes()
                val hours = (total / 60.0).toInt()
                val minutes = total - hours * 60.0
                hoursInput.setText(hours.toString())
                minutesInput.setText(DecimalFormat("#.###").format(minutes))
                useClockInput = true
                updateMode()
            }
        }
        updateMode()
    }

    private fun parseNumber(value: String): Double {
        return try {
            NumberFormat.getInstance().parse(value)?.toDouble() ?: 0.0
        } catch (_: ParseException) {
            value.replace(',', '.').toDoubleOrNull() ?: 0.0
        }
    }

    private fun getEnteredValue(): Double {
        forcedValue?.let { return it }
        val factor = timeMinutesPerUnit
        if (factor != null) {
            val minutes = if (useClockInput) {
                val hours = parseNumber(view.root.findViewById<EditText>(R.id.timeHoursInput)
                    .text.toString()).coerceAtLeast(0.0)
                val mins = parseNumber(view.root.findViewById<EditText>(R.id.timeMinutesInput)
                    .text.toString()).coerceAtLeast(0.0)
                hours * 60.0 + mins
            } else {
                parseNumber(view.value.text.toString())
            }
            return (minutes / factor).coerceAtLeast(0.0)
        }
        val valueStr = view.value.text.toString()
        return if (valueStr.isNotEmpty()) parseNumber(valueStr) else Entry.UNKNOWN.toDouble() / 1000
    }

    private fun fixDecimalSeparator(view: CheckmarkPopupBinding) {
        // https://stackoverflow.com/a/34256139
        val separator = DecimalFormatSymbols.getInstance().decimalSeparator
        view.value.keyListener = DigitsKeyListener.getInstance("0123456789$separator")

        // https://github.com/flutter/flutter/issues/61175
        val currKeyboard = Settings.Secure.getString(
            requireContext().contentResolver,
            Settings.Secure.DEFAULT_INPUT_METHOD
        )
        if (currKeyboard?.contains("swiftkey") == true || currKeyboard?.contains("samsung") == true) {
            view.value.inputType = EditorInfo.TYPE_CLASS_TEXT
        }
    }

    private fun getEnteredTimeMinutesMilli(): Long? {
        if (timeMinutesPerUnit == null || forcedValue != null) return null
        val hoursInput = view.root.findViewById<EditText>(R.id.timeHoursInput)
        val minutesInput = view.root.findViewById<EditText>(R.id.timeMinutesInput)
        val minutes = if (useClockInput) {
            val hours = parseNumber(hoursInput.text.toString()).coerceAtLeast(0.0)
            val mins = parseNumber(minutesInput.text.toString()).coerceAtLeast(0.0)
            hours * 60.0 + mins
        } else {
            parseNumber(view.value.text.toString()).coerceAtLeast(0.0)
        }
        return (minutes * 1000.0).roundToLong()
    }

    fun save() {
        val value = getEnteredValue()
        val notes = view.notes.text.toString()
        onToggle(value, notes, getEnteredTimeMinutesMilli())
        requireDialog().dismiss()
    }
}
