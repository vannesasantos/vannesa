package org.isoron.uhabits.activities.habits.icons

import org.isoron.uhabits.R

data class HabitIconDefinition(
    val key: String,
    val label: String,
    val codePoint: Int,
    val category: String,
    val reaction: Reaction = Reaction.BOUNCE,
    val drawableResId: Int? = null
) {
    enum class Reaction { BOUNCE, RUN, GROW, MUSIC }
    val glyph: String get() = String(Character.toChars(codePoint))
}

/** A curated, searchable set of Loop Motion icon choices using the bundled Font Awesome 5 Free font. */
object HabitIconCatalog {
    val categories = listOf("Movement", "Wellness", "Learning", "Creative", "Daily life")

    val all: List<HabitIconDefinition> = listOf(
        // Movement
        HabitIconDefinition("running", "Running", 0xf70c, "Movement", HabitIconDefinition.Reaction.RUN),
        HabitIconDefinition("walking", "Walking", 0xf554, "Movement", HabitIconDefinition.Reaction.RUN),
        HabitIconDefinition("bicycle", "Cycling", 0xf206, "Movement", HabitIconDefinition.Reaction.RUN),
        HabitIconDefinition("dumbbell", "Strength", 0xf44b, "Movement"),
        HabitIconDefinition("swimmer", "Swimming", 0xf5c4, "Movement", HabitIconDefinition.Reaction.RUN),
        HabitIconDefinition("hiking", "Hiking", 0xf6ec, "Movement", HabitIconDefinition.Reaction.RUN),
        HabitIconDefinition("basketball", "Basketball", 0xf434, "Movement", HabitIconDefinition.Reaction.RUN),
        HabitIconDefinition("football", "Football", 0xf44e, "Movement", HabitIconDefinition.Reaction.RUN),
        HabitIconDefinition("yoga", "Yoga", 0xf6ad, "Movement"),
        HabitIconDefinition("weight", "Weight training", 0xf496, "Movement"),
        HabitIconDefinition("skating", "Skating", 0xf7c5, "Movement", HabitIconDefinition.Reaction.RUN),
        HabitIconDefinition("heartbeat", "Cardio", 0xf21e, "Movement"),
        // Wellness
        HabitIconDefinition("spa", "Meditation", 0xf5bb, "Wellness", HabitIconDefinition.Reaction.GROW),
        HabitIconDefinition("leaf", "Nature", 0xf06c, "Wellness", HabitIconDefinition.Reaction.GROW),
        HabitIconDefinition("seedling", "Plant care", 0xf4d8, "Wellness", HabitIconDefinition.Reaction.GROW),
        HabitIconDefinition("tree", "Gardening", 0xf1bb, "Wellness", HabitIconDefinition.Reaction.GROW),
        HabitIconDefinition("water", "Water", 0xf773, "Wellness"),
        HabitIconDefinition("tint", "Hydration", 0xf043, "Wellness"),
        HabitIconDefinition("bed", "Sleep", 0xf236, "Wellness"),
        HabitIconDefinition("moon", "Rest", 0xf186, "Wellness"),
        HabitIconDefinition("sun", "Sunlight", 0xf185, "Wellness"),
        HabitIconDefinition("heart", "Self care", 0xf004, "Wellness"),
        HabitIconDefinition("medkit", "Health", 0xf0fa, "Wellness"),
        HabitIconDefinition("apple", "Nutrition", 0xf5d1, "Wellness"),
        HabitIconDefinition("utensils", "Cooking", 0xf2e7, "Wellness"),
        // Learning
        HabitIconDefinition("book", "Reading", 0xf02d, "Learning"),
        HabitIconDefinition("book-open", "Study", 0xf518, "Learning"),
        HabitIconDefinition("graduation", "Learning", 0xf19d, "Learning"),
        HabitIconDefinition("brain", "Brain training", 0xf5dc, "Learning"),
        HabitIconDefinition("lightbulb", "Ideas", 0xf0eb, "Learning"),
        HabitIconDefinition("pencil", "Writing", 0xf303, "Learning"),
        HabitIconDefinition("language", "Languages", 0xf1ab, "Learning"),
        HabitIconDefinition("calculator", "Math", 0xf1ec, "Learning"),
        HabitIconDefinition("glasses", "Research", 0xf530, "Learning"),
        HabitIconDefinition("atom", "Science", 0xf5d2, "Learning"),
        // Creative
        HabitIconDefinition("music", "Music", 0xf001, "Creative", HabitIconDefinition.Reaction.MUSIC),
        HabitIconDefinition("piano", "Instrument", 0xf001, "Creative", HabitIconDefinition.Reaction.MUSIC, R.drawable.ic_habit_piano),
        HabitIconDefinition("headphones", "Listening", 0xf025, "Creative", HabitIconDefinition.Reaction.MUSIC),
        HabitIconDefinition("palette", "Art", 0xf53f, "Creative"),
        HabitIconDefinition("paint-brush", "Painting", 0xf1fc, "Creative"),
        HabitIconDefinition("camera", "Photography", 0xf030, "Creative"),
        HabitIconDefinition("code", "Coding", 0xf121, "Creative"),
        HabitIconDefinition("laptop", "Digital work", 0xf109, "Creative"),
        HabitIconDefinition("microphone", "Singing", 0xf130, "Creative", HabitIconDefinition.Reaction.MUSIC),
        HabitIconDefinition("film", "Film", 0xf008, "Creative"),
        // Daily life
        HabitIconDefinition("home", "Home", 0xf015, "Daily life"),
        HabitIconDefinition("wallet", "Finance", 0xf555, "Daily life"),
        HabitIconDefinition("piggy-bank", "Saving", 0xf4d3, "Daily life"),
        HabitIconDefinition("shopping-bag", "Shopping", 0xf290, "Daily life"),
        HabitIconDefinition("calendar-check", "Planning", 0xf274, "Daily life"),
        HabitIconDefinition("clock", "Time", 0xf017, "Daily life"),
        HabitIconDefinition("car", "Driving", 0xf1b9, "Daily life"),
        HabitIconDefinition("plane", "Travel", 0xf072, "Daily life"),
        HabitIconDefinition("dog", "Dog care", 0xf6d3, "Daily life"),
        HabitIconDefinition("cat", "Cat care", 0xf6be, "Daily life"),
        HabitIconDefinition("paw", "Pets", 0xf1b0, "Daily life"),
        HabitIconDefinition("coffee", "Coffee", 0xf0f4, "Daily life"),
        HabitIconDefinition("users", "Family", 0xf0c0, "Daily life"),
        HabitIconDefinition("tools", "Home projects", 0xf7d9, "Daily life"),
        HabitIconDefinition("star", "Personal goal", 0xf005, "Daily life")
    )

    private val byKey = all.associateBy { it.key }

    /** Preserve older saved instrument selections while using the piano as the instrument icon. */
    fun canonicalKey(key: String): String = when (key) {
        "violin", "guitar" -> "piano"
        else -> key
    }

    fun get(key: String): HabitIconDefinition? = byKey[canonicalKey(key)]
}
