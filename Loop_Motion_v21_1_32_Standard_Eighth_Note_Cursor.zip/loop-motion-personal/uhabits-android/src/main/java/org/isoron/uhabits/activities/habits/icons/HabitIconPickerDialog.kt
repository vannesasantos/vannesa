package org.isoron.uhabits.activities.habits.icons

import android.app.Activity
import android.content.res.ColorStateList
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.GridLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import org.isoron.uhabits.R
import org.isoron.uhabits.utils.InterfaceUtils
import org.isoron.uhabits.utils.MotionFeedback
import kotlin.math.roundToInt

object HabitIconPickerDialog {
    fun show(activity: Activity, selectedKey: String, onSelected: (String) -> Unit) {
        val canonicalSelectedKey = HabitIconCatalog.canonicalKey(selectedKey)
        val density = activity.resources.displayMetrics.density
        fun dp(value: Int) = (value * density).roundToInt()
        val attrs = activity.obtainStyledAttributes(intArrayOf(R.attr.contrast0, R.attr.contrast20, R.attr.contrast80, R.attr.contrast100))
        val tile = attrs.getColor(1, 0xFF0A172D.toInt())
        val muted = attrs.getColor(2, 0xFF8796B0.toInt())
        val textColor = attrs.getColor(3, 0xFFF4F1E8.toInt())
        attrs.recycle()
        val accent = activity.getColor(R.color.motion_accent)
        val frameBorder = activity.getColor(R.color.motion_gold_border)
        val font = InterfaceUtils.getFontAwesome(activity) ?: Typeface.DEFAULT

        val root = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(8), dp(18), dp(8))
        }
        val search = EditText(activity).apply {
            hint = activity.getString(R.string.icon_search_hint)
            setSingleLine(true)
            textSize = 15f
            setTextColor(textColor)
            setHintTextColor(muted)
            setPadding(dp(12), 0, dp(12), 0)
            background = GradientDrawable().apply {
                cornerRadius = dp(14).toFloat()
                setColor(tile)
                setStroke(1, frameBorder)
            }
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48)).apply {
                bottomMargin = dp(10)
            }
        }
        root.addView(search)

        var dialogHolder: AlertDialog? = null
        val noneButton = TextView(activity).apply {
            text = activity.getString(R.string.icon_none)
            gravity = Gravity.CENTER
            textSize = 14f
            setTextColor(textColor)
            background = GradientDrawable().apply {
                cornerRadius = dp(14).toFloat()
                setColor(tile)
                setStroke(1, frameBorder)
            }
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(42)).apply {
                bottomMargin = dp(10)
            }
            setOnClickListener { onSelected(""); dialogHolder?.dismiss() }
            MotionFeedback.bindPress(this, pressedScale = 0.975f)
        }
        root.addView(noneButton)

        val scroll = ScrollView(activity).apply {
            isFillViewport = true
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(430))
        }
        val content = LinearLayout(activity).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(content)
        root.addView(scroll)

        fun render(query: String, animateTiles: Boolean = false) {
            content.removeAllViews()
            var tileEntranceIndex = 0
            val needle = query.trim().lowercase()
            for (category in HabitIconCatalog.categories) {
                val icons = HabitIconCatalog.all.filter {
                    it.category == category && (needle.isEmpty() ||
                        it.label.lowercase().contains(needle) || it.key.contains(needle))
                }
                if (icons.isEmpty()) continue
                val header = TextView(activity).apply {
                    text = category
                    textSize = 13f
                    setTypeface(null, Typeface.BOLD)
                    setTextColor(muted)
                    setPadding(0, dp(10), 0, dp(7))
                }
                content.addView(header)
                val grid = GridLayout(activity).apply {
                    columnCount = 4
                    useDefaultMargins = false
                    alignmentMode = GridLayout.ALIGN_MARGINS
                    layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                }
                icons.forEach { icon ->
                    val cell = LinearLayout(activity).apply {
                        orientation = LinearLayout.VERTICAL
                        gravity = Gravity.CENTER
                        setPadding(dp(3), dp(6), dp(3), dp(4))
                        background = GradientDrawable().apply {
                            cornerRadius = dp(13).toFloat()
                            setColor(if (icon.key == canonicalSelectedKey) activity.getColor(R.color.motion_gold_tint) else tile)
                            setStroke(1, frameBorder)
                        }
                        contentDescription = icon.label
                        setOnClickListener {
                            MotionFeedback.selection(this)
                            onSelected(icon.key)
                            dialogHolder?.dismiss()
                        }
                        MotionFeedback.bindPress(this, pressedScale = 0.955f)
                    }
                    val glyph: View = if (icon.drawableResId != null) {
                        ImageView(activity).apply {
                            setImageResource(icon.drawableResId)
                            imageTintList = ColorStateList.valueOf(accent)
                            scaleType = ImageView.ScaleType.FIT_CENTER
                            setPadding(dp(4), dp(4), dp(4), dp(4))
                        }
                    } else {
                        TextView(activity).apply {
                            text = icon.glyph
                            typeface = font
                            textSize = 23f
                            gravity = Gravity.CENTER
                            setTextColor(accent)
                            includeFontPadding = false
                        }
                    }
                    val label = TextView(activity).apply {
                        text = icon.label
                        textSize = 9.5f
                        maxLines = 1
                        gravity = Gravity.CENTER
                        setTextColor(textColor)
                        includeFontPadding = false
                    }
                    cell.addView(glyph, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(34)))
                    cell.addView(label, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(17)))
                    val params = GridLayout.LayoutParams().apply {
                        width = 0
                        height = dp(65)
                        columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
                        setMargins(dp(3), dp(3), dp(3), dp(3))
                    }
                    grid.addView(cell, params)
                    if (animateTiles) {
                        MotionFeedback.entrance(
                            cell,
                            delayMillis = (tileEntranceIndex * 10L).coerceAtMost(160L),
                            distanceDp = 5f
                        )
                    }
                    tileEntranceIndex++
                }
                content.addView(grid)
            }
            if (content.childCount == 0) {
                content.addView(TextView(activity).apply {
                    text = activity.getString(R.string.icon_no_results)
                    setTextColor(muted)
                    gravity = Gravity.CENTER
                    setPadding(0, dp(30), 0, dp(30))
                })
            }
        }
        render("", animateTiles = true)
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) = render(s?.toString().orEmpty())
            override fun afterTextChanged(s: Editable?) = Unit
        })

        val dialog = AlertDialog.Builder(activity)
            .setTitle(R.string.choose_habit_icon)
            .setView(root)
            .setNegativeButton(android.R.string.cancel, null)
            .create()
        dialogHolder = dialog
        dialog.setOnShowListener {
            dialog.window?.setLayout(
                (activity.resources.displayMetrics.widthPixels - dp(32)).coerceAtLeast(dp(280)),
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
            dialog.getButton(AlertDialog.BUTTON_POSITIVE)?.let { MotionFeedback.bindPress(it) }
            MotionFeedback.dialogContent(dialog)
        }
        dialog.show()
    }
}
