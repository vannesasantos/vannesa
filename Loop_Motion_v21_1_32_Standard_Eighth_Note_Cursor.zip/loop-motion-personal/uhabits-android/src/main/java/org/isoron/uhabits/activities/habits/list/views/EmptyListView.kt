/*
 * Copyright (C) 2016-2021 Álinson Santos Xavier <git@axavier.org>
 *
 * This file is part of Loop Habit Tracker.
 *
 * Loop Habit Tracker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or (at your
 * option) any later version.
 *
 * Loop Habit Tracker is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 * or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
 * more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program. If not, see <http://www.gnu.org/licenses/>.
 */

package org.isoron.uhabits.activities.habits.list.views

import android.content.Context
import android.graphics.drawable.GradientDrawable
import android.view.Gravity.CENTER
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.view.animation.DecelerateInterpolator
import android.widget.LinearLayout
import android.widget.TextView
import org.isoron.uhabits.R
import org.isoron.uhabits.utils.dp
import org.isoron.uhabits.utils.getFontAwesome
import org.isoron.uhabits.utils.sp
import org.isoron.uhabits.utils.sres
import org.isoron.uhabits.utils.str
import org.isoron.uhabits.utils.MotionSettings

class EmptyListView(context: Context) : LinearLayout(context) {
    var textTextView: TextView
    var iconTextView: TextView

    init {
        orientation = VERTICAL
        gravity = CENTER
        visibility = View.GONE

        iconTextView = TextView(context).apply {
            text = str(R.string.fa_star_half_o)
            typeface = getFontAwesome()
            textSize = sp(38.0f)
            gravity = CENTER
            setTextColor(sres.getColor(R.attr.colorAccent))
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(sres.getColor(R.attr.highlightedBackgroundColor))
                setStroke(1, sres.getColor(R.color.motion_gold_border))
            }
            elevation = dp(2.0f)
        }

        addView(
            iconTextView,
            LinearLayout.LayoutParams(dp(92.0f).toInt(), dp(92.0f).toInt()).apply {
                bottomMargin = dp(6.0f).toInt()
            }
        )

        textTextView = TextView(context).apply {
            text = str(R.string.motion_empty_state_message)
            gravity = CENTER
            textSize = 15f
            typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
            maxLines = 2
            setPadding(dp(16.0f).toInt(), dp(12.0f).toInt(), dp(16.0f).toInt(), 0)
            setTextColor(sres.getColor(R.attr.contrast60))
        }
        addView(
            textTextView,
            MATCH_PARENT,
            WRAP_CONTENT
        )
    }

    fun showDone() {
        showState(
            str(R.string.fa_umbrella_beach),
            str(R.string.no_habits_left_to_do),
            showIcon = true
        )
    }

    fun showEmpty() {
        showState(
            str(R.string.fa_star_half_o),
            str(R.string.motion_empty_state_message),
            showIcon = false
        )
    }

    private fun showState(icon: String, message: String, showIcon: Boolean) {
        val desiredIconVisibility = if (showIcon) VISIBLE else GONE
        val shouldAnimate = visibility != VISIBLE ||
            iconTextView.visibility != desiredIconVisibility ||
            (showIcon && iconTextView.text.toString() != icon) ||
            textTextView.text.toString() != message
        iconTextView.text = icon
        iconTextView.visibility = desiredIconVisibility
        textTextView.text = message
        textTextView.setPadding(
            dp(16.0f).toInt(),
            if (showIcon) dp(12.0f).toInt() else 0,
            dp(16.0f).toInt(),
            0
        )
        visibility = VISIBLE
        if (!shouldAnimate) return

        iconTextView.animate().cancel()
        textTextView.animate().cancel()
        if (!MotionSettings.isEnabled(context)) {
            resetAnimationState()
            return
        }

        if (showIcon) {
            iconTextView.alpha = 0f
            iconTextView.scaleX = 0.82f
            iconTextView.scaleY = 0.82f
        }
        textTextView.alpha = 0f
        textTextView.translationY = dp(7.0f)

        if (showIcon) {
            iconTextView.animate()
                .alpha(1f)
                .scaleX(1f)
                .scaleY(1f)
                .setDuration(340L)
                .setInterpolator(DecelerateInterpolator(1.6f))
                .start()
        }
        textTextView.animate()
            .alpha(1f)
            .translationY(0f)
            .setStartDelay(70L)
            .setDuration(280L)
            .setInterpolator(DecelerateInterpolator(1.3f))
            .start()
    }

    fun hide() {
        iconTextView.animate().cancel()
        textTextView.animate().cancel()
        resetAnimationState()
        visibility = GONE
    }

    private fun resetAnimationState() {
        iconTextView.alpha = 1f
        iconTextView.scaleX = 1f
        iconTextView.scaleY = 1f
        textTextView.alpha = 1f
        textTextView.translationY = 0f
    }
}
