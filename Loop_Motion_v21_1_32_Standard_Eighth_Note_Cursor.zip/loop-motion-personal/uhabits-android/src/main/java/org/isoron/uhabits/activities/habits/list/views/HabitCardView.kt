/*
 * Copyright (C) 2016-2021 Álinson Santos Xavier <git@axavier.org>
 *
 * This file is part of Loop Habit Tracker.
 *
 * Loop Habit Tracker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or (at your
 * option) any later version.
 *
 * Loop Habit Tracker is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 * or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
 * more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program. If not, see <http://www.gnu.org/licenses/>.
 */

package org.isoron.uhabits.activities.habits.list.views

import android.content.Context
import android.graphics.PointF
import android.graphics.text.LineBreaker.BREAK_STRATEGY_BALANCED
import android.os.Build
import android.os.Build.VERSION.SDK_INT
import android.os.Handler
import android.os.Looper
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.view.animation.DecelerateInterpolator
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import org.isoron.platform.gui.toInt
import org.isoron.uhabits.R
import org.isoron.uhabits.activities.common.views.RingView
import org.isoron.uhabits.core.models.Habit
import org.isoron.uhabits.core.models.Entry
import org.isoron.uhabits.core.models.ModelObservable
import org.isoron.uhabits.core.models.Timestamp
import org.isoron.uhabits.core.ui.screens.habits.list.ListHabitsBehavior
import org.isoron.uhabits.core.utils.DateUtils
import org.isoron.uhabits.inject.ActivityContext
import org.isoron.uhabits.utils.currentTheme
import org.isoron.uhabits.utils.dp
import org.isoron.uhabits.utils.sres
import org.isoron.uhabits.utils.MotionSettings
import javax.inject.Inject

class HabitCardViewFactory
@Inject constructor(
    @ActivityContext val context: Context,
    private val checkmarkPanelFactory: CheckmarkPanelViewFactory,
    private val numberPanelFactory: NumberPanelViewFactory,
    private val behavior: ListHabitsBehavior
) {
    fun create() = HabitCardView(context, checkmarkPanelFactory, numberPanelFactory, behavior)
}

class HabitCardView(
    @ActivityContext context: Context,
    checkmarkPanelFactory: CheckmarkPanelViewFactory,
    numberPanelFactory: NumberPanelViewFactory,
    private val behavior: ListHabitsBehavior
) : FrameLayout(context),
    ModelObservable.Listener {

    var buttonCount
        get() = checkmarkPanel.buttonCount
        set(value) {
            checkmarkPanel.buttonCount = value
            numberPanel.buttonCount = value
        }

    var dataOffset = 0
        set(value) {
            field = value
            checkmarkPanel.dataOffset = value
            numberPanel.dataOffset = value
        }

    var habit: Habit? = null
        set(newHabit) {
            if (isAttachedToWindow) {
                field?.observable?.removeListener(this)
                newHabit?.observable?.addListener(this)
            }
            field = newHabit
            if (newHabit != null) copyAttributesFrom(newHabit)
        }

    var score
        get() = scoreRing.getPercentage().toDouble()
        set(value) {
            scoreRing.setPercentage(value.toFloat())
            scoreRing.setPrecision(1.0f / 16)
        }

    var unit
        get() = numberPanel.units
        set(value) {
            numberPanel.units = value
        }

    var values
        get() = checkmarkPanel.values
        set(values) {
            checkmarkPanel.values = values
            numberPanel.values = values.map { it / 1000.0 }.toDoubleArray()
        }

    var threshold: Double
        get() = numberPanel.threshold
        set(value) {
            numberPanel.threshold = value
        }

    var notes
        get() = checkmarkPanel.notes
        set(values) {
            checkmarkPanel.notes = values
            numberPanel.notes = values
        }

    var checkmarkPanel: CheckmarkPanelView
    private var numberPanel: NumberPanelView
    private var innerFrame: LinearLayout
    private var label: TextView
    private var scoreRing: RingView
    private var iconView: HabitIconView
    private var pendingNumericReaction: Pair<Timestamp, Int>? = null

    private var currentToggleTaskId = 0
    private var hasPlayedEntranceAnimation = false

    init {
        scoreRing = RingView(context).apply {
            val thickness = dp(3f)
            val margin = dp(8f).toInt()
            val ringSize = dp(15f).toInt()
            layoutParams = LinearLayout.LayoutParams(ringSize, ringSize).apply {
                setMargins(margin, 0, margin, 0)
                gravity = Gravity.CENTER
            }
            setThickness(thickness)
        }

        label = TextView(context).apply {
            maxLines = 2
            ellipsize = TextUtils.TruncateAt.END
            layoutParams = LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f)
            if (SDK_INT >= Build.VERSION_CODES.Q) {
                breakStrategy = BREAK_STRATEGY_BALANCED
            }
        }

        iconView = HabitIconView(context)

        checkmarkPanel = checkmarkPanelFactory.create().apply {
            onToggle = { timestamp, value, notes ->
                triggerRipple(timestamp)
                val location = getAbsoluteButtonLocation(timestamp)
                habit?.let {
                    behavior.onToggle(
                        it,
                        timestamp,
                        value,
                        notes,
                        location.x,
                        location.y
                    )
                }
                if (value == Entry.YES_MANUAL || value == Entry.YES_AUTO) {
                    iconView.playCompletionAnimation()
                }
            }
            onEdit = { timestamp ->
                triggerRipple(timestamp)
                val location = getAbsoluteButtonLocation(timestamp)
                habit?.let { behavior.onEdit(it, timestamp, location.x, location.y) }
            }
        }

        numberPanel = numberPanelFactory.create().apply {
            visibility = GONE
            onEdit = { timestamp ->
                triggerRipple(timestamp)
                val location = getAbsoluteButtonLocation(timestamp)
                habit?.let {
                    pendingNumericReaction = timestamp to it.computedEntries.get(timestamp).value
                    behavior.onEdit(it, timestamp, location.x, location.y)
                }
            }
        }

        innerFrame = LinearLayout(context).apply {
            gravity = Gravity.CENTER_VERTICAL
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT)
            elevation = 0f

            addView(scoreRing)
            addView(iconView, LinearLayout.LayoutParams(dp(34f).toInt(), dp(34f).toInt()).apply {
                marginEnd = dp(6f).toInt()
            })
            addView(label)
            addView(checkmarkPanel)
            addView(numberPanel)

        }

        clipToPadding = false
        layoutParams = LayoutParams(MATCH_PARENT, WRAP_CONTENT)
        val margin = dp(5f).toInt()
        // Keep a fine, visible separation between consecutive habit cards.
        setPadding(margin, 0, margin, dp(1.5f).toInt())
        addView(innerFrame)
    }

    /** Places a newly inserted card immediately, without the staggered entrance offset.
     * This avoids a temporary oversized visual gap while the list is reflowing. */
    fun showImmediately() {
        hasPlayedEntranceAnimation = true
        animate().cancel()
        alpha = 1f
        translationY = 0f
        scaleX = 1f
        scaleY = 1f
    }

    /** Plays once for each newly created card, not every time RecyclerView
     * reuses the view. A small stagger makes the initial list feel deliberate
     * without delaying interaction with the cards. */
    fun playEntranceAnimationOnce(startDelayMillis: Long = 0L) {
        if (hasPlayedEntranceAnimation) return
        hasPlayedEntranceAnimation = true
        animate().cancel()
        if (!MotionSettings.isEnabled(context)) {
            alpha = 1f
            translationY = 0f
            return
        }
        alpha = 0f
        translationY = dp(12f)
        scaleX = 0.988f
        scaleY = 0.988f
        animate()
            .alpha(1f)
            .translationY(0f)
            .scaleX(1f)
            .scaleY(1f)
            .setStartDelay(startDelayMillis.coerceAtMost(180L))
            .setDuration(330L)
            .setInterpolator(DecelerateInterpolator(1.6f))
            .start()
    }

    fun animateCardPress(pressed: Boolean) {
        innerFrame.animate().cancel()
        if (!MotionSettings.isEnabled(context)) {
            innerFrame.scaleX = 1f
            innerFrame.scaleY = 1f
            innerFrame.translationZ = 0f
            return
        }
        val targetScale = if (pressed) 0.992f else 1f
        innerFrame.animate()
            .scaleX(targetScale)
            .scaleY(targetScale)
            .translationZ(if (pressed) dp(1.5f) else 0f)
            .setDuration(if (pressed) 72L else 175L)
            .setInterpolator(DecelerateInterpolator(1.4f))
            .start()
    }

    fun animateDragState(active: Boolean) {
        innerFrame.animate().cancel()
        if (!MotionSettings.isEnabled(context)) {
            innerFrame.scaleX = 1f
            innerFrame.scaleY = 1f
            innerFrame.translationZ = 0f
            return
        }
        innerFrame.animate()
            .scaleX(if (active) 1.018f else 1f)
            .scaleY(if (active) 1.018f else 1f)
            .translationZ(if (active) dp(7f) else 0f)
            .setDuration(if (active) 150L else 220L)
            .setInterpolator(DecelerateInterpolator(1.35f))
            .start()
    }

    override fun onDetachedFromWindow() {
        // Stop all view animations and restore neutral transforms before recycling.
        animate().cancel()
        innerFrame.animate().cancel()
        alpha = 1f
        translationY = 0f
        innerFrame.scaleX = 1f
        innerFrame.scaleY = 1f
        innerFrame.translationZ = 0f
        iconView.resetAnimation()
        pendingNumericReaction = null

        // Detach the observable listener as well; this view is about to leave the window.
        habit?.observable?.removeListener(this)
        super.onDetachedFromWindow()
    }

    override fun onWindowFocusChanged(hasWindowFocus: Boolean) {
        super.onWindowFocusChanged(hasWindowFocus)
        if (!hasWindowFocus) return
        val pending = pendingNumericReaction ?: return
        pendingNumericReaction = null
        postDelayed({
            val currentHabit = habit ?: return@postDelayed
            val currentValue = currentHabit.computedEntries.get(pending.first).value
            if (currentValue != pending.second && currentValue > 0 &&
                currentValue != Entry.SKIP && currentValue != Entry.UNKNOWN
            ) {
                iconView.playCompletionAnimation()
            }
        }, 120L)
    }

    override fun onModelChange() {
        Handler(Looper.getMainLooper()).post {
            habit?.let { copyAttributesFrom(it) }
        }
    }

    override fun setSelected(isSelected: Boolean) {
        super.setSelected(isSelected)
        updateBackground(isSelected)
    }

    fun triggerRipple(timestamp: Timestamp) {
        val location = getRelativeButtonLocation(timestamp)
        triggerRipple(location.x, location.y)
    }

    private fun getRelativeButtonLocation(timestamp: Timestamp): PointF {
        val today = DateUtils.getTodayWithOffset()
        val offset = timestamp.daysUntil(today) - dataOffset
        val panel = when (habit!!.isNumerical) {
            true -> numberPanel
            false -> checkmarkPanel
        }
        val button = panel.buttons[offset]
        val y = button.height / 2.0f
        val x = panel.x + button.x + (button.width / 2).toFloat()
        return PointF(x, y)
    }

    private fun getAbsoluteButtonLocation(timestamp: Timestamp): PointF {
        val containerLocation = IntArray(2)
        this.getLocationInWindow(containerLocation)
        val relButtonLocation = getRelativeButtonLocation(timestamp)
        val windowInsets = rootWindowInsets
        val xInset = windowInsets?.displayCutout?.safeInsetLeft ?: 0
        val yInset = if (SDK_INT <= Build.VERSION_CODES.VANILLA_ICE_CREAM) {
            windowInsets?.systemWindowInsetTop ?: 0
        } else {
            0
        }
        return PointF(
            containerLocation[0].toFloat() + relButtonLocation.x - xInset,
            containerLocation[1].toFloat() + relButtonLocation.y - yInset
        )
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        habit?.observable?.addListener(this)
    }

    private fun copyAttributesFrom(h: Habit) {
        fun getActiveColor(habit: Habit): Int {
            return when (habit.isArchived) {
                true -> sres.getColor(R.attr.contrast60)
                false -> currentTheme().color(habit.color).toInt()
            }
        }

        val c = getActiveColor(h)
        label.apply {
            text = h.name
            setTextColor(c)
        }
        scoreRing.apply {
            setColor(c)
        }
        iconView.bind(h.iconKey, c, h.iconKey.isNotBlank())
        checkmarkPanel.apply {
            color = c
            visibility = when (h.isNumerical) {
                true -> View.GONE
                false -> View.VISIBLE
            }
        }
        numberPanel.apply {
            color = c
            units = h.unit
            targetType = h.targetType
            threshold = h.targetValue
            visibility = when (h.isNumerical) {
                true -> View.VISIBLE
                false -> View.GONE
            }
        }
    }

    private fun triggerRipple(x: Float, y: Float) {
        val background = innerFrame.background
        background.setHotspot(x, y)
        background.state = intArrayOf(
            android.R.attr.state_pressed,
            android.R.attr.state_enabled
        )
        Handler().postDelayed({ background.state = intArrayOf() }, 25)
    }

    private fun updateBackground(isSelected: Boolean) {
        val background = when (isSelected) {
            true -> R.drawable.selected_box
            false -> R.drawable.ripple
        }
        innerFrame.setBackgroundResource(background)
    }

    companion object {
        fun (() -> Unit).delay(delayInMillis: Long) {
            Handler(Looper.getMainLooper()).postDelayed(this, delayInMillis)
        }
    }
}
