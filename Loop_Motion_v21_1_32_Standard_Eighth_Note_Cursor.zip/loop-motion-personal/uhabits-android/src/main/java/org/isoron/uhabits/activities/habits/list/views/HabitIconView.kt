package org.isoron.uhabits.activities.habits.list.views

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.TextView
import org.isoron.uhabits.activities.habits.icons.HabitIconCatalog
import org.isoron.uhabits.activities.habits.icons.HabitIconDefinition
import org.isoron.uhabits.utils.InterfaceUtils
import org.isoron.uhabits.utils.MotionSettings
import org.isoron.uhabits.utils.dp
import kotlin.math.roundToInt

/** Compact home-card icon with short, category-aware completion reactions. */
class HabitIconView(context: Context) : FrameLayout(context) {
    private val glyphView = TextView(context)
    private val drawableView = ImageView(context)
    private var iconKey: String = ""
    private var iconColor: Int = Color.WHITE

    init {
        layoutParams = LayoutParams(dp(34f).roundToInt(), dp(34f).roundToInt())
        clipChildren = false
        clipToPadding = false
        glyphView.apply {
            gravity = Gravity.CENTER
            includeFontPadding = false
            textSize = 19f
            typeface = InterfaceUtils.getFontAwesome(context) ?: Typeface.DEFAULT
        }
        addView(glyphView, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT))
        drawableView.apply {
            scaleType = ImageView.ScaleType.FIT_CENTER
            setPadding(dp(5f).roundToInt(), dp(5f).roundToInt(), dp(5f).roundToInt(), dp(5f).roundToInt())
            visibility = GONE
        }
        addView(drawableView, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT))
        visibility = GONE
    }

    fun bind(key: String, color: Int, show: Boolean) {
        iconKey = key
        iconColor = color
        val definition = HabitIconCatalog.get(key)
        visibility = if (show && definition != null) VISIBLE else GONE
        if (definition == null) {
            glyphView.text = ""
            return
        }
        background = null
        if (definition.drawableResId != null) {
            glyphView.text = ""
            glyphView.visibility = GONE
            drawableView.setImageResource(definition.drawableResId)
            drawableView.setColorFilter(color, android.graphics.PorterDuff.Mode.SRC_IN)
            drawableView.visibility = VISIBLE
        } else {
            drawableView.setImageDrawable(null)
            drawableView.visibility = GONE
            glyphView.text = definition.glyph
            glyphView.setTextColor(color)
            glyphView.visibility = VISIBLE
        }
    }

    fun playCompletionAnimation() {
        val definition = HabitIconCatalog.get(iconKey) ?: return
        if (visibility != VISIBLE || !MotionSettings.isEnabled(context)) return
        val motionView = currentIconView()
        motionView.animate().cancel()
        motionView.apply {
            alpha = 1f
            scaleX = 1f
            scaleY = 1f
            rotation = 0f
            translationX = 0f
            translationY = 0f
            pivotX = width / 2f
            pivotY = height.toFloat()
        }
        when (definition.reaction) {
            HabitIconDefinition.Reaction.RUN -> playRunning()
            HabitIconDefinition.Reaction.GROW -> playGrowth()
            HabitIconDefinition.Reaction.MUSIC -> playMusicNotes()
            HabitIconDefinition.Reaction.BOUNCE -> playBounce()
        }
    }

    private fun currentIconView(): View = if (drawableView.visibility == VISIBLE) drawableView else glyphView

    private fun playBounce() {
        currentIconView().animate().scaleX(1.26f).scaleY(1.26f).rotation(8f)
            .setDuration(150L).withEndAction {
                currentIconView().animate().scaleX(1f).scaleY(1f).rotation(0f)
                    .setDuration(220L).start()
            }.start()
        addFloatingMarks(listOf("✦"), listOf(0f), listOf(-dp(12f)))
    }

    private fun playRunning() {
        currentIconView().animate().translationX(-dp(3f)).rotation(-9f).setDuration(110L)
            .withEndAction {
                currentIconView().animate().translationX(dp(3f)).rotation(9f).setDuration(110L)
                    .withEndAction {
                        currentIconView().animate().translationX(0f).rotation(0f).setDuration(110L).start()
                    }.start()
            }.start()
        addFloatingMarks(listOf("•", "•"), listOf(-dp(9f), dp(9f)), listOf(-dp(5f), -dp(1f)))
    }

    private fun playGrowth() {
        currentIconView().apply {
            scaleY = 0.28f
            scaleX = 0.86f
            alpha = 0.55f
        }
        currentIconView().animate().scaleY(1f).scaleX(1f).alpha(1f)
            .setDuration(480L).start()
        addFloatingMarks(listOf("✦", "✧"), listOf(-dp(11f), dp(11f)), listOf(-dp(10f), -dp(5f)))
    }

    private fun playMusicNotes() {
        currentIconView().animate().translationY(-dp(3f)).scaleX(1.12f).scaleY(1.12f)
            .setDuration(180L).withEndAction {
                currentIconView().animate().translationY(0f).scaleX(1f).scaleY(1f)
                    .setDuration(240L).start()
            }.start()
        val notes = listOf("♪", "♫", "♬")
        val offsets = listOf(-dp(12f), 0f, dp(12f))
        notes.forEachIndexed { index, note ->
            val particle = TextView(context).apply {
                text = note
                textSize = if (index == 1) 15f else 12f
                setTextColor(iconColor)
                alpha = 0.95f
                gravity = Gravity.CENTER
                includeFontPadding = false
            }
            addView(particle, LayoutParams(dp(18f).roundToInt(), dp(18f).roundToInt(), Gravity.CENTER))
            particle.translationX = offsets[index]
            particle.translationY = dp(3f)
            particle.animate()
                .translationY(-dp((23 + index * 3).toFloat()))
                .translationX(offsets[index] + if (index == 1) dp(4f) else offsets[index] / 3f)
                .alpha(0f)
                .setStartDelay(index * 90L)
                .setDuration(720L)
                .withEndAction { removeView(particle) }
                .start()
        }
    }

    fun resetAnimation() {
        listOf(glyphView, drawableView).forEach { view ->
            view.animate().cancel()
            view.alpha = 1f
            view.scaleX = 1f
            view.scaleY = 1f
            view.rotation = 0f
            view.translationX = 0f
            view.translationY = 0f
        }
        for (index in childCount - 1 downTo 0) {
            val child = getChildAt(index)
            child.animate().cancel()
            if (child !== glyphView && child !== drawableView) removeViewAt(index)
        }
    }

    override fun onDetachedFromWindow() {
        resetAnimation()
        super.onDetachedFromWindow()
    }

    private fun addFloatingMarks(symbols: List<String>, x: List<Float>, y: List<Float>) {
        symbols.forEachIndexed { index, symbol ->
            val mark = TextView(context).apply {
                text = symbol
                textSize = 10f
                gravity = Gravity.CENTER
                setTextColor(iconColor)
                alpha = 0.9f
                includeFontPadding = false
            }
            addView(mark, LayoutParams(dp(12f).roundToInt(), dp(12f).roundToInt(), Gravity.CENTER))
            mark.translationX = x[index]
            mark.translationY = 0f
            mark.animate().translationX(x[index] * 1.35f).translationY(y[index])
                .alpha(0f).setStartDelay(index * 45L).setDuration(520L)
                .withEndAction { removeView(mark) }.start()
        }
    }
}
