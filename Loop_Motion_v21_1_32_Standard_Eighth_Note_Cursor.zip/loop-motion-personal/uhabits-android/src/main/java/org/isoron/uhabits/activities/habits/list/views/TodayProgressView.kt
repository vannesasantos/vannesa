/*
 * Copyright (C) 2016-2026 Loop Motion Personal contributors.
 *
 * This file is part of Loop Motion, a personal modification of Loop Habit Tracker.
 * It is distributed under the GNU General Public License version 3 or later.
 */
package org.isoron.uhabits.activities.habits.list.views

import android.animation.LayoutTransition
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.util.TypedValue
import android.view.View
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.roundToInt
import org.isoron.uhabits.R
import org.isoron.uhabits.utils.MotionSettings
import org.isoron.uhabits.utils.MotionFeedback

/**
 * A compact animated overview of today's progress, shown above the date strip.
 * It is deliberately read-only and uses the same underlying habit state as
 * the rest of Loop; no additional data is stored.
 */
class TodayProgressView(context: Context) : LinearLayout(context) {
    private val title = TextView(context)
    private val count = TextView(context)
    private val subtitle = TextView(context)
    private val track = AnimatedProgressTrackView(context)
    private val expandChevron = TextView(context)
    private val details = LinearLayout(context)
    private val completedValue = TextView(context)
    private val remainingValue = TextView(context)
    private var expanded = false
    private var lastCompleted = -1
    private var lastTotal = -1
    private var lastPercent = -1

    /** Called once when progress changes from incomplete to a complete day. */
    var onPerfectDayCompleted: (() -> Unit)? = null

    init {
        orientation = LinearLayout.VERTICAL
        val density = resources.displayMetrics.density
        setPadding(px(12), px(8), px(12), px(8))
        background = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = 14f * density
            setColor(themeColor(R.attr.cardBgColor, 0xFF07142D.toInt()))
            // Slightly stronger than the standard hairline, while staying subtle.
            val frameStroke = (density * 0.75f).roundToInt().coerceAtLeast(1)
            setStroke(frameStroke, resources.getColor(R.color.motion_gold_border))
        }
        elevation = 0f
        clipToPadding = false
        clipChildren = false
        isClickable = true
        isFocusable = true
        updateLayoutTransition()
        setOnClickListener { setExpanded(!expanded) }

        val header = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }
        title.apply {
            text = context.getString(R.string.today_progress_title)
            textSize = 10f
            letterSpacing = 0.065f
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            setTextColor(themeColor(R.attr.contrast60, 0xFF8796B0.toInt()))
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        count.apply {
            textSize = 12f
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            setTextColor(themeColor(R.attr.contrast100, 0xFFF4F1E8.toInt()))
            gravity = android.view.Gravity.END or android.view.Gravity.CENTER_VERTICAL
        }
        expandChevron.apply {
            text = "⌄"
            textSize = 18f
            gravity = android.view.Gravity.CENTER
            setTextColor(themeColor(R.attr.contrast60, 0xFF8796B0.toInt()))
            contentDescription = context.getString(R.string.today_progress_expand)
            importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
            layoutParams = LinearLayout.LayoutParams(px(24), ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                marginStart = px(5)
            }
        }
        header.addView(title)
        header.addView(count)
        header.addView(expandChevron)
        addView(header)

        subtitle.apply {
            textSize = 11f
            setTextColor(themeColor(R.attr.contrast60, 0xFF8796B0.toInt()))
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = px(3) }
        }
        addView(subtitle)

        track.layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            px(6)
        ).apply { topMargin = px(7) }
        addView(track)

        details.orientation = LinearLayout.HORIZONTAL
        details.visibility = View.GONE
        details.importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO_HIDE_DESCENDANTS
        details.layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = px(9) }
        val completedPill = createDetailPill(
            R.string.today_progress_detail_completed,
            completedValue,
            themeColor(R.attr.colorAccent, 0xFFFFD34B.toInt())
        )
        val remainingPill = createDetailPill(
            R.string.today_progress_detail_remaining,
            remainingValue,
            themeColor(R.attr.contrast60, 0xFF8796B0.toInt())
        )
        details.addView(completedPill, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
            marginEnd = px(6)
        })
        details.addView(remainingPill, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        addView(details)
        importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_YES
        MotionFeedback.bindPress(this, pressedScale = 0.992f)
    }

    private fun updateLayoutTransition() {
        layoutTransition = if (MotionSettings.isEnabled(context)) {
            LayoutTransition().apply {
                setDuration(180L)
                enableTransitionType(LayoutTransition.CHANGING)
            }
        } else {
            null
        }
    }

    fun updateProgress(progress: Pair<Int, Int>) {
        val completed = progress.first.coerceAtLeast(0)
        val total = progress.second.coerceAtLeast(0)
        if (completed == lastCompleted && total == lastTotal) return

        val previousCompleted = lastCompleted
        val previousTotal = lastTotal
        val previousPercent = lastPercent
        val hadPreviousProgress = previousCompleted >= 0

        lastCompleted = completed
        lastTotal = total
        val safeCompleted = completed.coerceAtMost(total)
        val remaining = (total - safeCompleted).coerceAtLeast(0)
        val percent = if (total > 0) ((safeCompleted * 100.0) / total).toInt().coerceIn(0, 100) else 0
        lastPercent = percent

        completedValue.text = safeCompleted.toString()
        remainingValue.text = remaining.toString()
        count.text = if (total > 0) {
            context.getString(R.string.today_progress_count, safeCompleted, total, percent)
        } else {
            context.getString(R.string.today_progress_empty)
        }
        val message = when {
            total <= 0 -> context.getString(R.string.today_progress_message_empty)
            percent >= 100 -> context.getString(R.string.today_progress_message_done)
            percent >= 75 -> context.getString(R.string.today_progress_message_almost)
            percent >= 50 -> context.getString(R.string.today_progress_message_halfway)
            percent > 0 -> context.getString(R.string.today_progress_message_building)
            else -> context.getString(R.string.today_progress_message_start)
        }
        val messageChanged = subtitle.text.toString() != message
        subtitle.text = message

        updateAccessibilityDescription(safeCompleted, total, remaining, percent)
        track.setProgress(percent / 100f)

        if (hadPreviousProgress && messageChanged) animateMessageChange()
        val crossedMilestone = listOf(25, 50, 75, 100).any {
            previousPercent < it && percent >= it
        }
        if (hadPreviousProgress && completed > previousCompleted && total == previousTotal && crossedMilestone) {
            animateMilestone()
        }

        // Celebrate only on a real transition into 100%, not on initial screen load
        // or when the habit list itself changes size.
        if (hadPreviousProgress && total > 0 && previousPercent in 0..99 && percent == 100 &&
            completed > previousCompleted && total == previousTotal
        ) {
            onPerfectDayCompleted?.invoke()
        }
    }

    private fun createDetailPill(
        labelId: Int,
        valueView: TextView,
        accent: Int
    ): LinearLayout {
        return LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(px(10), px(7), px(10), px(7))
            valueView.apply {
                textSize = 17f
                typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
                setTextColor(accent)
                importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
            }
            addView(valueView)
            addView(TextView(context).apply {
                text = context.getString(labelId)
                textSize = 10f
                setTextColor(themeColor(R.attr.contrast60, 0xFF8796B0.toInt()))
                importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
            })
        }
    }

    private fun setExpanded(value: Boolean) {
        if (expanded == value) return
        expanded = value
        updateLayoutTransition()
        details.importantForAccessibility = if (expanded) {
            View.IMPORTANT_FOR_ACCESSIBILITY_AUTO
        } else {
            View.IMPORTANT_FOR_ACCESSIBILITY_NO_HIDE_DESCENDANTS
        }
        details.visibility = if (expanded) View.VISIBLE else View.GONE
        expandChevron.contentDescription = context.getString(
            if (expanded) R.string.today_progress_collapse else R.string.today_progress_expand
        )
        expandChevron.text = "⌄"
        if (MotionSettings.isEnabled(context)) {
            expandChevron.animate().cancel()
            expandChevron.animate()
                .rotation(if (expanded) 180f else 0f)
                .setDuration(180L)
                .setInterpolator(DecelerateInterpolator(1.3f))
                .start()
        } else {
            expandChevron.rotation = if (expanded) 180f else 0f
        }
        val safeCompleted = lastCompleted.coerceAtLeast(0).coerceAtMost(lastTotal.coerceAtLeast(0))
        val total = lastTotal.coerceAtLeast(0)
        updateAccessibilityDescription(
            safeCompleted,
            total,
            (total - safeCompleted).coerceAtLeast(0),
            lastPercent.coerceAtLeast(0)
        )
    }

    private fun updateAccessibilityDescription(completed: Int, total: Int, remaining: Int, percent: Int) {
        val summary = context.getString(
            R.string.today_progress_accessibility,
            completed,
            total,
            percent
        )
        val expansionHint = context.getString(
            if (expanded) R.string.today_progress_collapse else R.string.today_progress_expand
        )
        contentDescription = if (expanded) {
            "${summary}. ${context.getString(R.string.today_progress_details_accessibility, completed, remaining)}. $expansionHint"
        } else {
            "$summary. $expansionHint"
        }
    }

    private fun animateMessageChange() {
        subtitle.animate().cancel()
        if (!MotionSettings.isEnabled(context)) {
            subtitle.alpha = 1f
            subtitle.translationY = 0f
            return
        }
        subtitle.alpha = 0.45f
        subtitle.translationY = px(3).toFloat()
        subtitle.animate()
            .alpha(1f)
            .translationY(0f)
            .setDuration(230L)
            .setInterpolator(DecelerateInterpolator(1.3f))
            .start()
    }

    private fun animateMilestone() {
        if (!MotionSettings.isEnabled(context)) return
        count.animate().cancel()
        count.scaleX = 1f
        count.scaleY = 1f
        count.animate()
            .scaleX(1.08f)
            .scaleY(1.08f)
            .setDuration(130L)
            .setInterpolator(DecelerateInterpolator(1.6f))
            .withEndAction {
                count.animate()
                    .scaleX(1f)
                    .scaleY(1f)
                    .setDuration(180L)
                    .setInterpolator(DecelerateInterpolator(1.3f))
                    .start()
            }
            .start()
    }

    override fun onDetachedFromWindow() {
        subtitle.animate().cancel()
        count.animate().cancel()
        subtitle.alpha = 1f
        subtitle.translationY = 0f
        count.scaleX = 1f
        count.scaleY = 1f
        expandChevron.animate().cancel()
        expandChevron.rotation = if (expanded) 180f else 0f
        super.onDetachedFromWindow()
    }

    private fun px(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun themeColor(attribute: Int, fallback: Int): Int {
        val value = TypedValue()
        if (!context.theme.resolveAttribute(attribute, value, true)) return fallback
        return if (value.resourceId != 0) {
            runCatching { context.getColor(value.resourceId) }.getOrDefault(fallback)
        } else {
            value.data
        }
    }

    private class AnimatedProgressTrackView(context: Context) : View(context) {
        private val density = resources.displayMetrics.density
        private val trackPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = themeColor(R.attr.contrast20, 0xFF09172D.toInt())
            style = Paint.Style.FILL
        }
        private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL
        }
        private val bounds = RectF()
        private val startColor = themeColor(R.attr.colorAccent, 0xFFFFD34B.toInt())
        private val endColor = themeColor(R.color.motion_brand_gold_light, 0xFFFFF3B2.toInt())
        private var value = 0f
        private var animator: ValueAnimator? = null

        init {
            importantForAccessibility = IMPORTANT_FOR_ACCESSIBILITY_NO
        }

        fun setProgress(target: Float) {
            val safeTarget = target.coerceIn(0f, 1f)
            animator?.cancel()
            animator = null
            if (!isAttachedToWindow || !MotionSettings.isEnabled(context)) {
                value = safeTarget
                invalidate()
                return
            }
            animator = ValueAnimator.ofFloat(value, safeTarget).apply {
                duration = 430L
                interpolator = DecelerateInterpolator(1.5f)
                addUpdateListener {
                    value = it.animatedValue as Float
                    invalidate()
                }
                start()
            }
        }

        override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
            super.onSizeChanged(w, h, oldw, oldh)
            fillPaint.shader = LinearGradient(
                0f, 0f, maxOf(1, w).toFloat(), 0f,
                startColor, endColor, Shader.TileMode.CLAMP
            )
        }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val inset = density * 0.5f
            bounds.set(inset, inset, width - inset, height - inset)
            val radius = height / 2f
            canvas.drawRoundRect(bounds, radius, radius, trackPaint)
            if (value <= 0f) return
            val fillRight = bounds.left + (bounds.width() * value)
            bounds.right = fillRight.coerceIn(bounds.left, width - inset)
            canvas.drawRoundRect(bounds, radius, radius, fillPaint)
        }

        override fun onDetachedFromWindow() {
            animator?.cancel()
            animator = null
            super.onDetachedFromWindow()
        }

        private fun themeColor(attribute: Int, fallback: Int): Int {
            val typedValue = TypedValue()
            if (!context.theme.resolveAttribute(attribute, typedValue, true)) return fallback
            return if (typedValue.resourceId != 0) {
                runCatching { context.getColor(typedValue.resourceId) }.getOrDefault(fallback)
            } else {
                typedValue.data
            }
        }
    }
}
