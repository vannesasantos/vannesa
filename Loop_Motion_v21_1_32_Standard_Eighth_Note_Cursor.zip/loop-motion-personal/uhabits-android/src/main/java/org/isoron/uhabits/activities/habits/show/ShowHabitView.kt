/*
 * Copyright (C) 2016-2021 Álinson Santos Xavier <git@axavier.org>
 *
 * This file is part of Loop Habit Tracker.
 *
 * Loop Habit Tracker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or (at your
 * option) any later version.
 *
 * Loop Habit Tracker is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 * or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
 * more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program. If not, see <http://www.gnu.org/licenses/>.
 */

package org.isoron.uhabits.activities.habits.show

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.widget.FrameLayout
import org.isoron.uhabits.core.ui.screens.habits.show.ShowHabitPresenter
import org.isoron.uhabits.core.ui.screens.habits.show.ShowHabitState
import org.isoron.uhabits.databinding.ShowHabitBinding
import org.isoron.uhabits.utils.applyBottomInset
import org.isoron.uhabits.utils.applyToolbarInsets
import org.isoron.uhabits.utils.setupToolbar
import org.isoron.uhabits.utils.MotionSettings

class ShowHabitView(context: Context) : FrameLayout(context) {
    private var hasPlayedDetailEntrance = false
    private val binding = ShowHabitBinding.inflate(LayoutInflater.from(context))

    init {
        binding.toolbar.applyToolbarInsets()
        addView(binding.root)
    }

    fun setState(data: ShowHabitState) {
        setupToolbar(
            binding.toolbar,
            title = data.title,
            color = data.color,
            theme = data.theme
        )
        binding.subtitleCard.setState(data.subtitle)
        binding.overviewCard.setState(data.overview)
        binding.notesCard.setState(data.notes)
        binding.targetCard.setState(data.target)
        binding.streakCard.setState(data.streaks)
        binding.scoreCard.setState(data.scores)
        binding.frequencyCard.setState(data.frequency)
        binding.historyCard.setState(data.history)
        binding.barCard.setState(data.bar)
        if (data.isNumerical) {
            binding.overviewCard.visibility = GONE
        } else {
            binding.targetCard.visibility = GONE
        }
        binding.linearLayout.applyBottomInset()
        animateDetailCardsOnce()
    }

    /** Entrance motion is one-shot and respects both Loop Motion's motion toggle
     * and Android's system-wide reduced-motion setting. */
    private fun animateDetailCardsOnce() {
        if (hasPlayedDetailEntrance) return
        hasPlayedDetailEntrance = true
        if (!MotionSettings.isEnabled(context)) return

        val cards = listOf(
            binding.subtitleCard,
            binding.notesCard,
            binding.overviewCard,
            binding.targetCard,
            binding.scoreCard,
            binding.barCard,
            binding.historyCard,
            binding.streakCard,
            binding.frequencyCard
        ).filter { it.visibility == View.VISIBLE }
        val offset = 14f * resources.displayMetrics.density
        cards.forEachIndexed { index, card ->
            card.alpha = 0f
            card.translationY = offset
            card.scaleY = 0.985f
            card.animate()
                .alpha(1f)
                .translationY(0f)
                .scaleY(1f)
                .setStartDelay((index * 26L).coerceAtMost(208L))
                .setDuration(310L)
                .setInterpolator(DecelerateInterpolator(1.3f))
                .start()
        }
    }

    fun setListener(presenter: ShowHabitPresenter) {
        binding.scoreCard.setListener(presenter.scoreCardPresenter)
        binding.historyCard.setListener(presenter.historyCardPresenter)
        binding.barCard.setListener(presenter.barCardPresenter)
    }
}
