/*
 * Loop Motion — custom full-screen launch screen.
 * The artwork is shown for four seconds before opening the main habit list.
 */
package org.isoron.uhabits.activities.splash

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import org.isoron.uhabits.R
import org.isoron.uhabits.activities.habits.list.ListHabitsActivity

class SplashActivity : AppCompatActivity() {

    private val handler = Handler(Looper.getMainLooper())
    private var startedAtElapsedRealtime: Long = 0L

    private val openMainActivity = Runnable {
        if (!isFinishing && !isDestroyed) {
            startActivity(Intent(this, ListHabitsActivity::class.java))
            finish()
            overridePendingTransition(0, 0)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        configureFullscreenWindow()

        val splashImage = ImageView(this).apply {
            setImageResource(R.drawable.splash_fullscreen)
            scaleType = ImageView.ScaleType.CENTER_CROP
            contentDescription = getString(R.string.app_name)
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT,
            )
        }
        setContentView(splashImage)

        startedAtElapsedRealtime = savedInstanceState?.getLong(STATE_STARTED_AT)
            ?.takeIf { it > 0L }
            ?: SystemClock.elapsedRealtime()

        val elapsed = SystemClock.elapsedRealtime() - startedAtElapsedRealtime
        val remaining = (SPLASH_DURATION_MS - elapsed).coerceAtLeast(0L)
        handler.postDelayed(openMainActivity, remaining)
    }

    private fun configureFullscreenWindow() {
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
        WindowCompat.setDecorFitsSystemWindows(window, false)

        WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior =
                WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }

        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.P) {
            window.attributes = window.attributes.apply {
                layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q) {
            window.isNavigationBarContrastEnforced = false
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        outState.putLong(STATE_STARTED_AT, startedAtElapsedRealtime)
        super.onSaveInstanceState(outState)
    }

    override fun onDestroy() {
        handler.removeCallbacks(openMainActivity)
        super.onDestroy()
    }

    companion object {
        private const val SPLASH_DURATION_MS = 4_000L
        private const val STATE_STARTED_AT = "loop_motion_splash_started_at"
    }
}
