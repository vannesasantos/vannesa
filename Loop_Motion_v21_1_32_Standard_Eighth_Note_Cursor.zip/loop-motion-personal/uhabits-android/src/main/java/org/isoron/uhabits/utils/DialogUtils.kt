package org.isoron.uhabits.utils

import android.app.Dialog
import androidx.fragment.app.DialogFragment
import androidx.fragment.app.FragmentManager
import java.lang.ref.WeakReference

var currentDialog: WeakReference<Dialog> = WeakReference(null)
var currentDialogFragment: WeakReference<DialogFragment> = WeakReference(null)

fun dismissCurrentDialog() {
    // Clear the weak references before dismissing. DialogFragment dismissals can
    // happen from their own Save/Cancel handlers, so the reference may point to
    // a fragment that has already been removed from FragmentManager.
    val dialog = currentDialog.get()
    currentDialog = WeakReference(null)
    if (dialog?.isShowing == true) dialog.dismiss()

    val fragment = currentDialogFragment.get()
    currentDialogFragment = WeakReference(null)
    if (fragment?.isAdded == true && !fragment.isRemoving && fragment.dialog?.isShowing == true) {
        fragment.dismissAllowingStateLoss()
    }
}

fun Dialog.dismissCurrentAndShow() {
    dismissCurrentDialog()
    currentDialog = WeakReference(this)
    show()
}

fun DialogFragment.dismissCurrentAndShow(fragmentManager: FragmentManager, tag: String) {
    dismissCurrentDialog()
    currentDialogFragment = WeakReference(this)
    show(fragmentManager, tag)
    fragmentManager.executePendingTransactions()
}
