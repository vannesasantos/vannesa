/*
 * Copyright (C) 2026 Loop Motion Personal contributors.
 * This file is part of Loop Motion and is distributed under GPL-3.0-or-later.
 */
package org.isoron.uhabits.utils

import android.app.Dialog
import android.view.MotionEvent
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import org.isoron.uhabits.R

/** Small, consistent interaction motions shared by Loop Motion's controls. */
object MotionFeedback {

    /** Adds a press-and-release response without consuming or replacing click events. */
    fun bindPress(view: View, pressedScale: Float = 0.965f) {
        if (view.getTag(R.id.motion_feedback_bound) == true) return
        view.setTag(R.id.motion_feedback_bound, true)
        val restingTranslationZ = view.translationZ

        view.setOnTouchListener { target, event ->
            val enabled = target.isEnabled && MotionSettings.isEnabled(target.context)
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    if (enabled) {
                        target.animate().cancel()
                        target.animate()
                            .scaleX(pressedScale)
                            .scaleY(pressedScale)
                            .translationZ(restingTranslationZ + 2f * target.resources.displayMetrics.density)
                            .setDuration(82L)
                            .setInterpolator(DecelerateInterpolator(1.5f))
                            .start()
                    }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL, MotionEvent.ACTION_OUTSIDE -> {
                    target.animate().cancel()
                    if (enabled) {
                        target.animate()
                            .scaleX(1f)
                            .scaleY(1f)
                            .translationZ(restingTranslationZ)
                            .setDuration(185L)
                            .setInterpolator(OvershootInterpolator(1.12f))
                            .start()
                    } else {
                        target.scaleX = 1f
                        target.scaleY = 1f
                        target.translationZ = restingTranslationZ
                    }
                }
            }
            // Returning false preserves the normal click, long-click and accessibility flow.
            false
        }
    }

    /** A restrained pop for a newly selected chip, swatch or mode. */
    fun selection(view: View) {
        // Haptic feedback is independent of visual motion preferences.
        view.performHapticFeedback(android.view.HapticFeedbackConstants.KEYBOARD_TAP)
        if (!MotionSettings.isEnabled(view.context)) return
        view.animate().cancel()
        view.scaleX = 0.94f
        view.scaleY = 0.94f
        view.animate()
            .scaleX(1f)
            .scaleY(1f)
            .setDuration(230L)
            .setInterpolator(OvershootInterpolator(1.25f))
            .start()
    }

    /** Soft fade/settle motion for dialog content and dynamically-added rows. */
    fun entrance(view: View, delayMillis: Long = 0L, distanceDp: Float = 8f) {
        view.animate().cancel()
        if (!MotionSettings.isEnabled(view.context)) {
            view.alpha = 1f
            view.translationY = 0f
            view.scaleX = 1f
            view.scaleY = 1f
            return
        }
        view.alpha = 0f
        view.translationY = distanceDp * view.resources.displayMetrics.density
        view.scaleX = 0.985f
        view.scaleY = 0.985f
        view.animate()
            .alpha(1f)
            .translationY(0f)
            .scaleX(1f)
            .scaleY(1f)
            .setStartDelay(delayMillis.coerceAtMost(160L))
            .setDuration(245L)
            .setInterpolator(DecelerateInterpolator(1.45f))
            .start()
    }

    /** Applies a one-time content entrance to a Dialog after its window is attached. */
    fun dialogContent(dialog: Dialog?) {
        val content = dialog?.window?.decorView?.findViewById<View>(android.R.id.content) ?: return
        content.post {
            if (content.isAttachedToWindow) entrance(content, distanceDp = 10f)
        }
    }

}
