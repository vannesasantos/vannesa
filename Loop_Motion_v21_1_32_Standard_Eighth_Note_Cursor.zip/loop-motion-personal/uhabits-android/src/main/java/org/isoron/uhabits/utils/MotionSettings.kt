/*
 * Copyright (C) 2026 Loop Motion Personal contributors.
 *
 * This file is part of Loop Motion, a personal modification of Loop Habit Tracker.
 * It is distributed under the GNU General Public License version 3 or later.
 */
package org.isoron.uhabits.utils

import android.animation.ValueAnimator
import android.content.Context
import androidx.preference.PreferenceManager

/** Central switch for the additional visual effects introduced by Loop Motion. */
object MotionSettings {
    const val KEY_ENHANCED_MOTION = "pref_enhanced_motion"

    /** True only when both the in-app preference and Android's motion setting permit animation. */
    fun isEnabled(context: Context): Boolean {
        if (!ValueAnimator.areAnimatorsEnabled()) return false
        return PreferenceManager.getDefaultSharedPreferences(context.applicationContext)
            .getBoolean(KEY_ENHANCED_MOTION, true)
    }
}
