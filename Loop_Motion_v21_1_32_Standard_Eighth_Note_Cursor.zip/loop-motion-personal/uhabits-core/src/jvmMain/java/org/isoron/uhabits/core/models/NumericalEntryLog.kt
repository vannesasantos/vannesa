/*
 * Copyright (C) 2016-2021 Álinson Santos Xavier
 * This file is part of Loop Habit Tracker and is distributed under GPL-3.0-or-later.
 */
package org.isoron.uhabits.core.models

/** A single, independently editable numerical registration for one habit day. */
data class NumericalEntryLog(
    val timestamp: Timestamp,
    val value: Int,
    val notes: String = "",
    val kind: Kind = Kind.ACTIVITY,
    /** Exact entered duration in thousandths of a minute; null for legacy/non-time entries. */
    val timeMinutesMilli: Long? = null
) {
    enum class Kind(val value: Int) {
        ACTIVITY(0),
        PREVIOUS_TOTAL(1),
        SIMPLE_MODE_ADJUSTMENT(2);

        companion object {
            fun fromInt(value: Int): Kind = values().firstOrNull { it.value == value } ?: ACTIVITY
        }
    }
}
