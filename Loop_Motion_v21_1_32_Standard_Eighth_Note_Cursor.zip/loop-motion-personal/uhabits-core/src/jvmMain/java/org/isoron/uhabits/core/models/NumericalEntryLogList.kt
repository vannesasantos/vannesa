/*
 * Copyright (C) 2016-2021 Álinson Santos Xavier
 * This file is part of Loop Habit Tracker and is distributed under GPL-3.0-or-later.
 */
package org.isoron.uhabits.core.models

/** Storage abstraction for the optional per-session history of numerical habits. */
open class NumericalEntryLogList {
    private val entries = hashMapOf<Timestamp, List<NumericalEntryLog>>()

    @Synchronized
    open fun get(timestamp: Timestamp): List<NumericalEntryLog> = entries[timestamp].orEmpty()

    @Synchronized
    open fun replace(timestamp: Timestamp, values: List<NumericalEntryLog>) {
        if (values.isEmpty()) entries.remove(timestamp) else entries[timestamp] = values.toList()
    }

    @Synchronized
    open fun clear() = entries.clear()
}
