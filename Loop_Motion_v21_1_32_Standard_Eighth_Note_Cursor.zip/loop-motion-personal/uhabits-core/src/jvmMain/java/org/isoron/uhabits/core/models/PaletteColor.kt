/*
 * Copyright (C) 2016-2021 Álinson Santos Xavier <git@axavier.org>
 *
 * This file is part of Loop Habit Tracker.
 *
 * Loop Habit Tracker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or (at
 * your option) any later version.
 */

package org.isoron.uhabits.core.models

/**
 * A habit color.
 *
 * Values 0..19 keep the original Loop palette indexes for full backward
 * compatibility. Custom colors are stored as opaque ARGB ints (negative on
 * Android/JVM because the alpha channel is 0xFF). This lets existing databases
 * keep using the same `color` column without a schema migration.
 */
data class PaletteColor(val paletteIndex: Int) {
    val isCustom: Boolean
        get() = paletteIndex < 0

    /** Returns the RGB portion for a custom color. */
    fun toCustomRgb(): Int = paletteIndex and 0x00FFFFFF

    fun toCsvColor(): String {
        if (isCustom) {
            return "#" + toCustomRgb().toString(16).uppercase().padStart(6, '0')
        }
        return arrayOf(
            "#D32F2F", //  0 red
            "#E64A19", //  1 deep orange
            "#F57C00", //  2 orange
            "#FF8F00", //  3 amber
            "#F9A825", //  4 yellow
            "#AFB42B", //  5 lime
            "#7CB342", //  6 light green
            "#388E3C", //  7 green
            "#00897B", //  8 teal
            "#00ACC1", //  9 cyan
            "#039BE5", // 10 light blue
            "#1976D2", // 11 blue
            "#303F9F", // 12 indigo
            "#5E35B1", // 13 deep purple
            "#8E24AA", // 14 purple
            "#D81B60", // 15 pink
            "#5D4037", // 16 brown
            "#303030", // 17 dark grey
            "#757575", // 18 grey
            "#aaaaaa" // 19 light grey
        )[paletteIndex]
    }

    fun compareTo(other: PaletteColor): Int {
        return paletteIndex.compareTo(other.paletteIndex)
    }

    companion object {
        /** Encodes an arbitrary opaque RGB/ARGB color without colliding with palette indexes. */
        @JvmStatic
        fun fromArgb(color: Int): PaletteColor = PaletteColor(color or (0xFF shl 24))
    }
}
