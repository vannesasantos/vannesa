/*
 * Copyright (C) 2016-2021 Álinson Santos Xavier
 * This file is part of Loop Habit Tracker and is distributed under GPL-3.0-or-later.
 */
package org.isoron.uhabits.core.models

import kotlin.math.roundToInt
import kotlin.math.roundToLong

/** Conversion helpers for common time units used as numerical habit units. */
object TimeUnitUtils {
    /** Number of minutes represented by one unit; null means this is not a recognized time unit. */
    fun minutesPerUnit(unit: String): Double? = when (unit.trim().lowercase().replace(" ", "")) {
        "min", "mins", "minute", "minutes", "دقیقه", "دقایق", "دقیقه‌ای" -> 1.0
        "h", "hr", "hrs", "hour", "hours", "ساعت" -> 60.0
        "d", "day", "days", "روز", "روزها" -> 1440.0
        "s", "sec", "secs", "second", "seconds", "ثانیه", "ثانیه‌ها" -> 1.0 / 60.0
        else -> null
    }

    fun toMinutes(value: Double, unit: String): Double? = minutesPerUnit(unit)?.let { value * it }

    fun fromMinutes(minutes: Double, unit: String): Double? = minutesPerUnit(unit)?.let { minutes / it }

    /**
     * Returns the precise total duration represented by a list of logs, in thousandths
     * of a minute. Older entries are converted from their legacy habit-unit value.
     */
    fun totalMinutesMilli(entries: List<NumericalEntryLog>, unit: String): Long? {
        if (entries.isEmpty()) return null
        val factor = minutesPerUnit(unit) ?: return null
        return entries.sumOf { entry ->
            entry.timeMinutesMilli ?: (entry.value / 1000.0 * factor).roundToLong() * 1000L
        }
    }

    fun formatDuration(minutes: Double): String {
        val totalSeconds = (minutes * 60.0).roundToInt().coerceAtLeast(0)
        val hours = totalSeconds / 3600
        val remainingAfterHours = totalSeconds % 3600
        val wholeMinutes = remainingAfterHours / 60
        val seconds = remainingAfterHours % 60
        return when {
            hours > 0 && seconds > 0 -> "${hours}h ${wholeMinutes}m ${seconds}s"
            hours > 0 -> "${hours}h ${wholeMinutes}m"
            wholeMinutes > 0 && seconds > 0 -> "${wholeMinutes}m ${seconds}s"
            wholeMinutes > 0 -> "${wholeMinutes}m"
            else -> "${seconds}s"
        }
    }
}
