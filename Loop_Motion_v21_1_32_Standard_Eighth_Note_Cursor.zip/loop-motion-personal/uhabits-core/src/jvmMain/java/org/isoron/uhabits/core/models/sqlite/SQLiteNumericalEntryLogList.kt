/*
 * Copyright (C) 2016-2021 Álinson Santos Xavier
 * This file is part of Loop Habit Tracker and is distributed under GPL-3.0-or-later.
 */
package org.isoron.uhabits.core.models.sqlite

import org.isoron.uhabits.core.database.Database
import org.isoron.uhabits.core.database.Repository
import org.isoron.uhabits.core.models.NumericalEntryLog
import org.isoron.uhabits.core.models.NumericalEntryLogList
import org.isoron.uhabits.core.models.Timestamp
import org.isoron.uhabits.core.models.sqlite.records.NumericalEntryLogRecord

class SQLiteNumericalEntryLogList(database: Database) : NumericalEntryLogList() {
    private val repository = Repository(NumericalEntryLogRecord::class.java, database)
    var habitId: Long? = null

    override fun get(timestamp: Timestamp): List<NumericalEntryLog> {
        val id = habitId ?: throw IllegalStateException("habitId must be set")
        return repository.findAll(
            "where habit_id = ? and timestamp = ? order by id",
            id.toString(),
            timestamp.unixTime.toString()
        ).map { it.toLog() }
    }

    override fun replace(timestamp: Timestamp, values: List<NumericalEntryLog>) {
        val id = habitId ?: throw IllegalStateException("habitId must be set")
        repository.executeAsTransaction {
            repository.execSQL(
                "delete from numerical_entry_logs where habit_id = ? and timestamp = ?",
                id,
                timestamp.unixTime
            )
            values.forEach { log ->
                val record = NumericalEntryLogRecord()
                record.copyFrom(id, log.copy(timestamp = timestamp))
                repository.save(record)
            }
        }
    }

    override fun clear() {
        val id = habitId ?: return
        repository.execSQL("delete from numerical_entry_logs where habit_id = ?", id)
    }
}
