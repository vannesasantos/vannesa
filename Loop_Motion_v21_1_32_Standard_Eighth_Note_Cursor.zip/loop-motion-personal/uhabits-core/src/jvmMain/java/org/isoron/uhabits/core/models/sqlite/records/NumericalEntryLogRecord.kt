/*
 * Copyright (C) 2016-2021 Álinson Santos Xavier
 * This file is part of Loop Habit Tracker and is distributed under GPL-3.0-or-later.
 */
package org.isoron.uhabits.core.models.sqlite.records

import org.isoron.uhabits.core.database.Column
import org.isoron.uhabits.core.database.Table
import org.isoron.uhabits.core.models.NumericalEntryLog
import org.isoron.uhabits.core.models.Timestamp

@Table(name = "numerical_entry_logs")
class NumericalEntryLogRecord {
    @field:Column(name = "habit_id")
    var habitId: Long? = null

    @field:Column
    var timestamp: Long? = null

    @field:Column
    var value: Int? = null

    @field:Column
    var notes: String? = null

    @field:Column
    var kind: Int? = null

    @field:Column(name = "time_minutes_milli")
    var timeMinutesMilli: Long? = null

    @field:Column
    var id: Long? = null

    fun copyFrom(habitId: Long, log: NumericalEntryLog) {
        this.habitId = habitId
        timestamp = log.timestamp.unixTime
        value = log.value
        notes = log.notes
        kind = log.kind.value
        timeMinutesMilli = log.timeMinutesMilli
    }

    fun toLog(): NumericalEntryLog = NumericalEntryLog(
        timestamp = Timestamp(timestamp!!),
        value = value!!,
        notes = notes ?: "",
        kind = NumericalEntryLog.Kind.fromInt(kind ?: 0),
        timeMinutesMilli = timeMinutesMilli
    )
}
