/*
 * Copyright (C) 2016-2021 Álinson Santos Xavier <git@axavier.org>
 *
 * This file is part of Loop Habit Tracker.
 *
 * Loop Habit Tracker is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or (at your
 * option) any later version.
 *
 * Loop Habit Tracker is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 * or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
 * more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program. If not, see <http://www.gnu.org/licenses/>.
 */
package org.isoron.uhabits.core.ui.screens.habits.list

import org.isoron.uhabits.core.commands.CommandRunner
import org.isoron.uhabits.core.commands.CreateRepetitionCommand
import org.isoron.uhabits.core.models.Entry.Companion.YES_MANUAL
import org.isoron.uhabits.core.models.Entry
import org.isoron.uhabits.core.models.Habit
import org.isoron.uhabits.core.models.HabitList
import org.isoron.uhabits.core.models.HabitType
import org.isoron.uhabits.core.models.NumericalEntryLog
import org.isoron.uhabits.core.models.NumericalHabitType.AT_LEAST
import org.isoron.uhabits.core.models.NumericalHabitType.AT_MOST
import org.isoron.uhabits.core.models.PaletteColor
import org.isoron.uhabits.core.models.Timestamp
import org.isoron.uhabits.core.models.TimeUnitUtils
import org.isoron.uhabits.core.preferences.Preferences
import org.isoron.uhabits.core.tasks.ExportCSVTask
import org.isoron.uhabits.core.tasks.TaskRunner
import org.isoron.uhabits.core.utils.DateUtils.Companion.getToday
import java.io.File
import java.io.IOException
import java.util.LinkedList
import javax.inject.Inject
import kotlin.math.roundToInt

open class ListHabitsBehavior @Inject constructor(
    private val habitList: HabitList,
    private val dirFinder: DirFinder,
    private val taskRunner: TaskRunner,
    private val screen: Screen,
    private val commandRunner: CommandRunner,
    private val prefs: Preferences,
    private val bugReporter: BugReporter
) {
    fun onClickHabit(h: Habit) {
        screen.showHabitScreen(h)
    }

    fun onEdit(habit: Habit, timestamp: Timestamp?, x: Float, y: Float) {
        val entry = habit.computedEntries.get(timestamp!!)
        if (habit.type == HabitType.NUMERICAL) {
            val oldValue = entry.value.toDouble() / 1000
            if (habit.isDetailedLogging) {
                screen.showDetailedNumberPopup(
                    unit = habit.unit,
                    timestamp = timestamp,
                    currentValue = habit.computedEntries.get(timestamp).value,
                    currentNotes = entry.notes,
                    entries = habit.detailedEntries.get(timestamp),
                    callback = { newEntries, wasEdited ->
                        val previousLogs = habit.detailedEntries.get(timestamp)
                        if (wasEdited || newEntries != previousLogs) {
                            habit.detailedEntries.replace(timestamp, newEntries)
                            val value = newEntries.sumOf { it.value.toLong() }
                                .coerceIn(Int.MIN_VALUE.toLong(), Int.MAX_VALUE.toLong()).toInt()
                            val newValue = value.toDouble() / 1000.0
                            val notes = newEntries.map { it.notes.trim() }
                                .filter { it.isNotEmpty() }
                                .distinct()
                                .joinToString("\n")
                            if (
                                (habit.targetType == AT_LEAST && newValue >= habit.targetValue) ||
                                (habit.targetType == AT_MOST && newValue <= habit.targetValue)
                            ) {
                                if (newValue != oldValue) screen.showConfetti(habit.color, x, y)
                            }
                            commandRunner.run(
                                CreateRepetitionCommand(habitList, habit, timestamp, value, notes)
                            )
                        }
                    },
                    onStatusPicked = { status ->
                        val notes = habit.detailedEntries.get(timestamp)
                            .map { it.notes.trim() }
                            .filter { it.isNotEmpty() }
                            .distinct()
                            .joinToString("\n")
                        commandRunner.run(
                            CreateRepetitionCommand(habitList, habit, timestamp, status, notes)
                        )
                    }
                )
            } else {
                val existingLogsForTime = habit.detailedEntries.get(timestamp)
                screen.showNumberPopup(
                    oldValue, entry.notes, habit.unit,
                    TimeUnitUtils.totalMinutesMilli(existingLogsForTime, habit.unit)
                ) { newValue: Double, newNotes: String, newTimeMinutesMilli: Long? ->
                    val value = (newValue * 1000).roundToInt()

                    // Detailed session records stay intact if the user changes
                    // to Simple mode. A separate adjustment keeps their sum in
                    // sync with the daily total entered in Simple mode.
                    val existingLogs = habit.detailedEntries.get(timestamp)
                    if (existingLogs.isNotEmpty() && value != Entry.SKIP && value != Entry.UNKNOWN) {
                        val preserved = existingLogs.filter {
                            it.kind != NumericalEntryLog.Kind.SIMPLE_MODE_ADJUSTMENT
                        }.toMutableList()
                        val preservedTotal = preserved.sumOf { it.value.toLong() }
                        val adjustment = (value.toLong() - preservedTotal)
                            .coerceIn(Int.MIN_VALUE.toLong(), Int.MAX_VALUE.toLong()).toInt()
                        val preservedTime = TimeUnitUtils.totalMinutesMilli(preserved, habit.unit)
                        val timeAdjustment = if (preservedTime != null && newTimeMinutesMilli != null) {
                            newTimeMinutesMilli - preservedTime
                        } else null
                        if (adjustment != 0 || (timeAdjustment != null && timeAdjustment != 0L)) {
                            preserved.add(
                                NumericalEntryLog(
                                    timestamp = timestamp,
                                    value = adjustment,
                                    notes = "",
                                    kind = NumericalEntryLog.Kind.SIMPLE_MODE_ADJUSTMENT,
                                    timeMinutesMilli = timeAdjustment
                                )
                            )
                        }
                        habit.detailedEntries.replace(timestamp, preserved)
                    } else if (
                        existingLogs.isEmpty() && newTimeMinutesMilli != null &&
                        value > 0 && value != Entry.SKIP && value != Entry.UNKNOWN
                    ) {
                        // Keep exact time for Simple-mode habits too, so a later switch
                        // to Detailed mode (or reopening the Simple editor) does not
                        // reconstruct minutes from a rounded hours/days value.
                        habit.detailedEntries.replace(
                            timestamp,
                            listOf(
                                NumericalEntryLog(
                                    timestamp = timestamp,
                                    value = value,
                                    kind = NumericalEntryLog.Kind.PREVIOUS_TOTAL,
                                    timeMinutesMilli = newTimeMinutesMilli
                                )
                            )
                        )
                    }

                    if (newValue != oldValue) {
                        if (
                            (habit.targetType == AT_LEAST && newValue >= habit.targetValue) ||
                            (habit.targetType == AT_MOST && newValue <= habit.targetValue)
                        ) {
                            screen.showConfetti(habit.color, x, y)
                        }
                    }
                    commandRunner.run(
                        CreateRepetitionCommand(habitList, habit, timestamp, value, newNotes)
                    )
                }
            }
        } else {
            screen.showCheckmarkPopup(
                entry.value,
                entry.notes,
                habit.color
            ) { newValue: Int, newNotes: String ->
                if (newValue != entry.value && newValue == YES_MANUAL) screen.showConfetti(habit.color, x, y)
                commandRunner.run(CreateRepetitionCommand(habitList, habit, timestamp, newValue, newNotes))
            }
        }
    }

    fun onExportCSV() {
        val selected: MutableList<Habit> = LinkedList()
        for (h in habitList) selected.add(h)
        val outputDir = dirFinder.getCSVOutputDir()
        taskRunner.execute(
            ExportCSVTask(habitList, selected, outputDir) { filename: String? ->
                if (filename != null) {
                    screen.showSendFileScreen(filename)
                } else {
                    screen.showMessage(
                        Message.COULD_NOT_EXPORT
                    )
                }
            }
        )
    }

    fun onFirstRun() {
        prefs.isFirstRun = false
        prefs.updateLastHint(-1, getToday())
    }

    fun onReorderHabit(from: Habit, to: Habit) {
        taskRunner.execute { habitList.reorder(from, to) }
    }

    fun onRepairDB() {
        taskRunner.execute {
            habitList.repair()
            screen.showMessage(Message.DATABASE_REPAIRED)
        }
    }

    fun onSendBugReport() {
        bugReporter.dumpBugReportToFile()
        try {
            val log = bugReporter.getBugReport()
            screen.showSendBugReportToDeveloperScreen(log)
        } catch (e: IOException) {
            e.printStackTrace()
            screen.showMessage(Message.COULD_NOT_GENERATE_BUG_REPORT)
        }
    }

    fun onStartup() {
        prefs.incrementLaunchCount()
        if (prefs.isFirstRun) onFirstRun()
    }

    fun onToggle(habit: Habit, timestamp: Timestamp, value: Int, notes: String, x: Float, y: Float) {
        commandRunner.run(
            CreateRepetitionCommand(habitList, habit, timestamp, value, notes)
        )
        if (value == YES_MANUAL) screen.showConfetti(habit.color, x, y)
    }

    enum class Message {
        COULD_NOT_EXPORT,
        IMPORT_SUCCESSFUL,
        IMPORT_FAILED,
        DATABASE_REPAIRED,
        COULD_NOT_GENERATE_BUG_REPORT,
        FILE_NOT_RECOGNIZED
    }

    interface BugReporter {
        fun dumpBugReportToFile()

        @Throws(IOException::class)
        fun getBugReport(): String
    }

    interface DirFinder {
        fun getCSVOutputDir(): File
    }

    fun interface NumberPickerCallback {
        fun onNumberPicked(
            newValue: Double,
            notes: String,
            timeMinutesMilli: Long?
        )
        fun onNumberPickerDismissed() {}
    }

    fun interface DetailedNumberPickerCallback {
        fun onEntriesPicked(entries: List<NumericalEntryLog>, wasEdited: Boolean)
    }

    fun interface CheckMarkDialogCallback {
        fun onNotesSaved(
            value: Int,
            notes: String
        )
        fun onNotesDismissed() {}
    }

    interface Screen {
        fun showHabitScreen(h: Habit)
        fun showMessage(m: Message)
        fun showNumberPopup(
            value: Double,
            notes: String,
            unit: String,
            timeMinutesMilli: Long?,
            callback: NumberPickerCallback
        )
        fun showDetailedNumberPopup(
            unit: String,
            timestamp: Timestamp,
            currentValue: Int,
            currentNotes: String,
            entries: List<NumericalEntryLog>,
            callback: DetailedNumberPickerCallback,
            onStatusPicked: (Int) -> Unit
        )
        fun showCheckmarkPopup(
            selectedValue: Int,
            notes: String,
            color: PaletteColor,
            callback: CheckMarkDialogCallback
        )
        fun showSendBugReportToDeveloperScreen(log: String)
        fun showSendFileScreen(filename: String)
        fun showConfetti(color: PaletteColor, x: Float, y: Float)
    }
}
