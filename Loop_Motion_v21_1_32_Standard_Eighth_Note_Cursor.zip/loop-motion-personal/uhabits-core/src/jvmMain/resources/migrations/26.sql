alter table habits add column registration_mode integer not null default 0;
create table numerical_entry_logs (id integer primary key autoincrement, habit_id integer not null, timestamp integer not null, value integer not null, notes text, kind integer not null default 0);
create index numerical_entry_logs_habit_timestamp_idx on numerical_entry_logs(habit_id, timestamp);
