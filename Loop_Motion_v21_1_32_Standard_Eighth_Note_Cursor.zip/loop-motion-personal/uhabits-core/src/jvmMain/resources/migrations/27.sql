alter table numerical_entry_logs add column time_minutes_milli integer;
