alter table habits add column icon_key text not null default '';
alter table habits add column show_icon integer not null default 1;
