package org.isoron.uhabits.core.models

import org.isoron.uhabits.core.ui.views.DarkTheme
import org.isoron.uhabits.core.ui.views.LightTheme
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class PaletteColorTest {
    @Test
    fun `legacy palette indices keep their CSV colors`() {
        assertEquals("#D32F2F", PaletteColor(0).toCsvColor())
        assertEquals("#00ACC1", PaletteColor(9).toCsvColor())
        assertEquals("#aaaaaa", PaletteColor(19).toCsvColor())
        assertFalse(PaletteColor(9).isCustom)
    }

    @Test
    fun `custom RGB colors round trip without changing legacy storage`() {
        val custom = PaletteColor.fromArgb(0xFFFFD900.toInt())
        assertTrue(custom.isCustom)
        assertEquals(0xFFFFD900.toInt(), custom.paletteIndex)
        assertEquals(0x00FFD900, custom.toCustomRgb())
        assertEquals("#FFD900", custom.toCsvColor())
    }

    @Test
    fun `custom colors look the same in light and dark themes`() {
        val custom = PaletteColor.fromArgb(0xFF18C7B5.toInt())
        val expected = org.isoron.platform.gui.Color(0x18C7B5)
        assertEquals(expected, LightTheme().color(custom))
        assertEquals(expected, DarkTheme().color(custom))
    }
}
