package org.isoron.uhabits.core.models

import org.hamcrest.CoreMatchers.equalTo
import org.hamcrest.MatcherAssert.assertThat
import org.junit.Test

class TimeUnitUtilsTest {
    @Test
    fun convertsBothTimeUnitsToTheSameValue() {
        val minuteEntry = TimeUnitUtils.fromMinutes(155.0, "minutes")
        val hourEntry = TimeUnitUtils.fromMinutes(155.0, "hours")

        assertThat(minuteEntry, equalTo(155.0))
        assertThat(hourEntry, equalTo(155.0 / 60.0))
        assertThat(TimeUnitUtils.toMinutes(hourEntry!!, "hours"), equalTo(minuteEntry))
    }

    @Test
    fun formatsDurationsInHoursAndMinutes() {
        assertThat(TimeUnitUtils.formatDuration(155.0), equalTo("2h 35m"))
        assertThat(TimeUnitUtils.formatDuration(45.0), equalTo("45m"))
        assertThat(TimeUnitUtils.formatDuration(0.5), equalTo("30s"))
        assertThat(TimeUnitUtils.formatDuration(80.5), equalTo("1h 20m 30s"))
    }

    @Test
    fun emptyLogListDoesNotOverrideLegacyDailyValue() {
        assertThat(TimeUnitUtils.totalMinutesMilli(emptyList(), "hours"), equalTo(null as Long?))
    }

    @Test
    fun exactMinuteDurationSurvivesRoundedHabitUnitStorage() {
        val timestamp = Timestamp(946684800000L)
        val entry = NumericalEntryLog(
            timestamp = timestamp,
            value = 1333, // 80 min represented in hours at legacy 1/1000 precision
            timeMinutesMilli = 80000L
        )

        assertThat(TimeUnitUtils.totalMinutesMilli(listOf(entry), "hours"), equalTo(80000L))
        val legacyEntry = entry.copy(timeMinutesMilli = null)
        assertThat(TimeUnitUtils.totalMinutesMilli(listOf(legacyEntry), "hours"), equalTo(80000L))
    }
}
